import 'package:flutter/material.dart';
import '../localization/localization.dart';

Widget buildAppDrawer(BuildContext context, String language) {
  final theme = Theme.of(context);
  final loc = Localization(language);

  return Drawer(
    child: ListView(
      padding: EdgeInsets.zero,
      children: [
        DrawerHeader(
          decoration: BoxDecoration(
            color: theme.colorScheme.primary, // Temanın primary rengi
          ),
          child: Center(
            child: Text(
              loc.menu,
              style: TextStyle(color: Colors.white, fontSize: 24),
            ),
          ),
        ),
        ListTile(
          title: Text(loc.stress),
          onTap: () {
            Navigator.pop(context);
            Navigator.pushReplacementNamed(context, '/stress');
          },
        ),
        ListTile(
          title: Text(loc.sleep),
          onTap: () {
            Navigator.pop(context);
            Navigator.pushReplacementNamed(context, '/sleep');
          },
        ),
        ListTile(
          title: Text(loc.nutrition),
          onTap: () {
            Navigator.pop(context);
            Navigator.pushReplacementNamed(context, '/nutrition');
          },
        ),
        ListTile(
          title: Text(loc.depression),
          onTap: () {
            Navigator.pop(context);
            Navigator.pushReplacementNamed(context, '/depression');
          },
        ),
        ListTile(
          title: Text(loc.addictions),
          onTap: () {
            Navigator.pop(context);
            Navigator.pushReplacementNamed(context, '/addictions');
          },
        ),
        Divider(),
        ListTile(
          leading: Icon(
            Icons.settings,
            color: theme.colorScheme.primary,
          ), // Tema rengiyle ikon
          title: Text(loc.settings),
          onTap: () {
            Navigator.pop(context);
            Navigator.pushReplacementNamed(context, '/settings');
          },
        ),
      ],
    ),
  );
}
