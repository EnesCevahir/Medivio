import 'package:flutter/material.dart';
import '../localization/localization.dart';
import '../widgets/app_drawer.dart';

class BasePage extends StatelessWidget {
  final Widget body;
  final String language;

  BasePage({required this.body, required this.language});

  @override
  Widget build(BuildContext context) {
    final loc = Localization(language);

    return Scaffold(
      drawer: buildAppDrawer(context, language),
      appBar: AppBar(
        title: Text(loc.title, style: TextStyle(color: Colors.black)),
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
        centerTitle: true,
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body: body,
    );
  }
}
