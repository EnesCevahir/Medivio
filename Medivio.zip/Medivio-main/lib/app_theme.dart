import 'package:flutter/material.dart';

final ThemeData appTheme = ThemeData(
  colorScheme: ColorScheme.fromSeed(
    seedColor: Color(0xFF2962FF), // Canlı mavi
    primary: Color(0xFF2962FF),
    secondary: Color(0xFFFF6D00), // Canlı turuncu
    onPrimary: Colors.white,
    onSecondary: Colors.white,
  ),
  scaffoldBackgroundColor: Color(0xFFE3F2FD), // Açık mavi arka plan
  appBarTheme: AppBarTheme(
    backgroundColor: Color(0xFF0039CB), // Koyu mavi
    iconTheme: IconThemeData(color: Colors.white),
    titleTextStyle: TextStyle(
      color: Colors.white,
      fontSize: 20,
      fontWeight: FontWeight.bold,
    ),
  ),
  drawerTheme: DrawerThemeData(
    backgroundColor: Color(0xFFFFF8E1), // Açık krem
  ),
  textTheme: TextTheme(
    bodyLarge: TextStyle(fontSize: 18, color: Color(0xFF212121)), // Koyu gri
    bodyMedium: TextStyle(fontSize: 16, color: Color(0xFF212121)),
  ),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: Color(0xFFFF6D00), // Turuncu butonlar
      foregroundColor: Colors.white,
    ),
  ),
);