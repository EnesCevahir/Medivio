import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'dart:convert';
import 'dart:async';
import 'package:flutter/services.dart' show rootBundle;

import 'my_app.dart';
import '../services/notification_service.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:uuid/uuid.dart'; // Eğer guid'i dinamik oluşturmak istersen

final initializationSettingsWindows = WindowsInitializationSettings(
  appName: 'Ruh Sağlığı Uygulaması',
  appUserModelId: 'com.example.medivio',
  guid: '7c39a7ac-8c95-4a74-9f13-bf0fdc3a4b67', // Örnek sabit GUID
);

// Bildirim objesi (global)
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

// Bildirim detayları
final androidDetails = AndroidNotificationDetails(
  'daily_alarm_channel',
  'Günlük Alarm',
  channelDescription: 'Her gün aynı saatte alarm',
  importance: Importance.max,
  priority: Priority.high,
  playSound: true,
  sound: RawResourceAndroidNotificationSound('alarm'),
);

final NotificationDetails platformDetails = NotificationDetails(
  android: androidDetails,
);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tz.initializeTimeZones();

  const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('@mipmap/ic_launcher');

  final initializationSettings = InitializationSettings(
    android: initializationSettingsAndroid,
    // eğer Windows desteği eklemediysen bunu kaldırabilirsin
    windows: initializationSettingsWindows,
  );

  await flutterLocalNotificationsPlugin.initialize(
    initializationSettings,
    onDidReceiveNotificationResponse: (NotificationResponse response) async {
      debugPrint("Bildirim tıklandı: ${response.payload}");
    },
  );

  runApp(MyApp());
}

Future<Map<String, List<String>>> loadDepressionTips() async {
  final jsonString = await rootBundle.loadString(
    'assets/data/depression_tips.json',
  );
  final Map<String, dynamic> jsonMap = jsonDecode(jsonString);
  return jsonMap.map((key, value) => MapEntry(key, List<String>.from(value)));
}

void alarmCallback() async {
  final player = AudioPlayer();
  await player.play(AssetSource('alarm.mp3'));
  print("⏰ Alarm çaldı!");
}
