import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import '../pages/home_page.dart';
import '../pages/anxiety_page.dart';
import '../pages/sleep_page.dart';
import '../pages/nutrition_page.dart';
import '../pages/depression_page.dart';
import '../pages/addictions_page.dart';
import '../pages/settings_page.dart';
import '../app_theme.dart'; // tema

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String _language = 'tr';

  void changeLanguage(String lang) {
    setState(() {
      _language = lang;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: appTheme,
      debugShowCheckedModeBanner: false,
      title: 'Medivio',
      locale: Locale(_language),
      supportedLocales: [Locale('tr'), Locale('en')],
      localizationsDelegates: [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: HomePage(language: _language),
      routes: {
        '/stress': (context) => AnxietyPage(language: _language),
        '/sleep': (context) => SleepPage(language: _language),
        '/nutrition': (context) => NutritionPage(language: _language),
        '/depression': (context) => DepressionPage(language: _language),
        '/addictions': (context) => AddictionsPage(language: _language),
        '/settings': (context) => SettingsPage(
          language: _language,
          onLanguageChanged: changeLanguage,
        ),
      },
    );
  }
}
