import 'package:flutter/material.dart';

class SocialMediaPage extends StatelessWidget {
  final String language;
  const SocialMediaPage({required this.language});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sosyal Medya Bağımlılığı'),
        leading: BackButton(onPressed: () => Navigator.pop(context)),
      ),
      body: Center(
        child: Text('Sosyal Medya bağımlılığı sayfası - Dil: $language'),
      ),
    );
  }
}
