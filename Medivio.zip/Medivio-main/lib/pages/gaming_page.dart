import 'package:flutter/material.dart';

class GamingPage extends StatelessWidget {
  final String language;
  const GamingPage({required this.language});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Oyun Bağımlılığı'),
        leading: BackButton(onPressed: () => Navigator.pop(context)),
      ),
      body: Center(child: Text('Oyun bağımlılığı sayfası - Dil: $language')),
    );
  }
}
