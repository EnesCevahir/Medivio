import 'package:flutter/material.dart';
import '../localization/localization.dart';
import '../pages/home_page.dart'; // Ana sayfaya dönüş için
// Eğer yol farklıysa bu import yolunu düzenle

class SettingsPage extends StatefulWidget {
  final String language;
  final ValueChanged<String> onLanguageChanged;

  SettingsPage({required this.language, required this.onLanguageChanged});

  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late String _selectedLanguage;

  @override
  void initState() {
    super.initState();
    _selectedLanguage = widget.language == 'tr' ? 'Türkçe' : 'English';
  }

  void _onLanguageChanged(String? newValue) {
    if (newValue == null) return;

    setState(() {
      _selectedLanguage = newValue;
    });

    widget.onLanguageChanged(newValue == 'Türkçe' ? 'tr' : 'en');
  }

  @override
  Widget build(BuildContext context) {
    final loc = Localization(widget.language);

    return Scaffold(
      appBar: AppBar(
        title: Text(loc.settings), // Örneğin: "Ayarlar"
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => HomePage(language: widget.language),
              ),
            );
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(loc.languageOption, style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            DropdownButton<String>(
              value: _selectedLanguage,
              items: <String>['Türkçe', 'English']
                  .map(
                    (value) => DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    ),
                  )
                  .toList(),
              onChanged: _onLanguageChanged,
            ),
            SizedBox(height: 20),
            Text(
              '${loc.selectedLanguage}: $_selectedLanguage',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }
}
