import 'package:flutter/material.dart';
import '../pages/home_page.dart';
import '../widgets/base_page.dart';
import '../localization/localization.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:audioplayers/audioplayers.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz;

class SleepPage extends StatefulWidget {
  final String language;

  SleepPage({required this.language});

  @override
  _SleepPageState createState() => _SleepPageState();
}

class _SleepPageState extends State<SleepPage> {
  bool _isLoading = true;
  TimeOfDay? _sleepTime;
  TimeOfDay? _wakeTime;
  bool _showTasks = false;
  Map<int, bool> _taskCompletion = {};

  final AudioPlayer _audioPlayer = AudioPlayer();
  Timer? _timer;
  bool _alarmActive = false;

  late List<String> _tasks;

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  @override
  void initState() {
    super.initState();
    tz.initializeTimeZones();
    _initializeNotifications();
    _initializeData();
    _timer = Timer.periodic(Duration(seconds: 30), (_) {
      final now = TimeOfDay.now();
      if (_sleepTime != null &&
          now.hour == _sleepTime!.hour &&
          now.minute == _sleepTime!.minute) {
        _showAlarmDialog();
      }
      if (_wakeTime != null &&
          now.hour == _wakeTime!.hour &&
          now.minute == _wakeTime!.minute) {
        _showAlarmDialog();
      }
    });
  }

  void _initializeNotifications() {
    const androidSettings = AndroidInitializationSettings(
      '@mipmap/ic_launcher',
    );
    final windowsSettings = WindowsInitializationSettings(
      appUserModelId: 'com.medivio.app',
      appName: 'medivio',
      guid: 'c9f24739-1d9a-46af-a0c3-4037764f916a',
    );

    final settings = InitializationSettings(
      android: androidSettings,
      windows: windowsSettings,
    );

    flutterLocalNotificationsPlugin.initialize(settings);
  }

  Future<void> _initializeData() async {
    _tasks = [
      Localization(widget.language).task1,
      Localization(widget.language).task2,
      Localization(widget.language).task3,
      Localization(widget.language).task4,
      Localization(widget.language).task5,
      Localization(widget.language).task6,
      Localization(widget.language).task7,
      Localization(widget.language).task8,
      Localization(widget.language).task9,
      Localization(widget.language).task10,
    ];
    await _loadTimesFromPrefs();
    await _loadTaskCompletion();
    await _checkAndResetTasksDaily();
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _loadTimesFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final sleepHour = prefs.getInt('sleepTime_hour');
    final sleepMinute = prefs.getInt('sleepTime_minute');
    final wakeHour = prefs.getInt('wakeTime_hour');
    final wakeMinute = prefs.getInt('wakeTime_minute');

    if (sleepHour != null && sleepMinute != null) {
      _sleepTime = TimeOfDay(hour: sleepHour, minute: sleepMinute);
    }
    if (wakeHour != null && wakeMinute != null) {
      _wakeTime = TimeOfDay(hour: wakeHour, minute: wakeMinute);
    }
  }

  Future<void> _loadTaskCompletion() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString('taskCompletion');
    if (jsonString != null) {
      final Map<String, dynamic> jsonMap = jsonDecode(jsonString);
      _taskCompletion = jsonMap.map<int, bool>((key, value) {
        bool val = false;
        if (value is bool) {
          val = value;
        } else if (value is String) {
          val = value.toLowerCase() == 'true';
        }
        return MapEntry(int.parse(key), val);
      });
    } else {
      for (int i = 0; i < _tasks.length; i++) {
        _taskCompletion[i] = false;
      }
    }
  }

  Future<void> _checkAndResetTasksDaily() async {
    final prefs = await SharedPreferences.getInstance();
    final lastResetMillis = prefs.getInt('lastTaskResetTime') ?? 0;
    final lastReset = DateTime.fromMillisecondsSinceEpoch(lastResetMillis);
    final now = DateTime.now();

    if (now.difference(lastReset) > Duration(hours: 24)) {
      for (int i = 0; i < _tasks.length; i++) {
        _taskCompletion[i] = false;
      }
      await _saveTaskCompletion();
      await prefs.setInt('lastTaskResetTime', now.millisecondsSinceEpoch);
    }
  }

  Future<void> _saveTaskCompletion() async {
    final prefs = await SharedPreferences.getInstance();
    final stringKeyMap = _taskCompletion.map(
      (key, value) => MapEntry(key.toString(), value),
    );
    final jsonString = jsonEncode(stringKeyMap);
    await prefs.setString('taskCompletion', jsonString);
  }

  Future<void> _selectTime(BuildContext context, bool isSleepTime) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() {
        if (isSleepTime)
          _sleepTime = picked;
        else
          _wakeTime = picked;
      });
      final prefs = await SharedPreferences.getInstance();
      if (isSleepTime) {
        await prefs.setInt('sleepTime_hour', picked.hour);
        await prefs.setInt('sleepTime_minute', picked.minute);
        await _scheduleSleepAlarm(picked); // 🔹 bu eklendi
      } else {
        await prefs.setInt('wakeTime_hour', picked.hour);
        await prefs.setInt('wakeTime_minute', picked.minute);
        await _scheduleWakeAlarm(picked); // 🔹 bu eklendi
      }
    }
  }

  void _showAlarmDialog() {
    if (!_alarmActive && mounted) {
      _alarmActive = true;
      _audioPlayer.setReleaseMode(ReleaseMode.loop);
      _audioPlayer.play(AssetSource('sounds/alarm.mp3'));
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          title: Text('Alarm!'),
          content: Text('Alarm zamanı geldi.'),
          actions: [
            TextButton(
              onPressed: () {
                _audioPlayer.stop();
                _alarmActive = false;
                if (mounted) Navigator.of(context).pop();
              },
              child: Text('Kapat'),
            ),
          ],
        ),
      );
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final loc = Localization(widget.language);

    return Scaffold(
      appBar: AppBar(
        title: Text(loc.sleepDesc),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => HomePage(language: widget.language),
              ),
            );
          },
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                loc.menu,
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text(loc.home),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => HomePage(language: widget.language),
                  ),
                );
              },
            ),
          ],
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: ListView(
          children: [
            ElevatedButton.icon(
              icon: Icon(Icons.bedtime),
              label: Text(
                _sleepTime == null
                    ? loc.selectSleepTime
                    : '${loc.sleepTime}: ${_sleepTime!.format(context)}',
              ),
              onPressed: () => _selectTime(context, true),
            ),
            if (_sleepTime != null)
              ElevatedButton.icon(
                icon: Icon(Icons.cancel),
                label: Text(loc.cancelSleepAlarm),
                onPressed: () => setState(() => _sleepTime = null),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              ),
            SizedBox(height: 20),
            ElevatedButton.icon(
              icon: Icon(Icons.wb_sunny),
              label: Text(
                _wakeTime == null
                    ? loc.selectWakeTime
                    : '${loc.wakeTime}: ${_wakeTime!.format(context)}',
              ),
              onPressed: () => _selectTime(context, false),
            ),
            if (_wakeTime != null)
              ElevatedButton.icon(
                icon: Icon(Icons.cancel),
                label: Text(loc.cancelWakeAlarm),
                onPressed: () => setState(() => _wakeTime = null),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              ),
            SizedBox(height: 20),
            ElevatedButton.icon(
              icon: Icon(_showTasks ? Icons.visibility_off : Icons.list),
              label: Text(_showTasks ? loc.hideTasks : loc.showTasks),
              onPressed: () {
                setState(() {
                  _showTasks = !_showTasks;
                });
              },
            ),
            if (_showTasks)
              Column(
                children: List.generate(_tasks.length, (index) {
                  return CheckboxListTile(
                    title: Text(_tasks[index]),
                    value: _taskCompletion[index] ?? false,
                    onChanged: (val) {
                      setState(() {
                        _taskCompletion[index] = val ?? false;
                      });
                      _saveTaskCompletion();
                    },
                  );
                }),
              ),
            SizedBox(height: 30),
            if (_sleepTime != null && _wakeTime != null)
              Center(
                child: Column(
                  children: [
                    Text(
                      "${loc.sleptAt}: ${_sleepTime!.format(context)}",
                      style: TextStyle(fontSize: 16),
                    ),
                    Text(
                      "${loc.wokeUpAt}: ${_wakeTime!.format(context)}",
                      style: TextStyle(fontSize: 16),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _scheduleWakeAlarm(TimeOfDay time) async {
    final now = DateTime.now();
    DateTime scheduledDate = DateTime(
      now.year,
      now.month,
      now.day,
      time.hour,
      time.minute,
    );

    // Eğer alarm zamanı geçmişteyse, bir gün ekle
    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(Duration(days: 1));
    }

    final tz.TZDateTime tzDate = tz.TZDateTime.from(scheduledDate, tz.local);

    await flutterLocalNotificationsPlugin.zonedSchedule(
      1,
      'Uyanma Saati',
      'Günaydın! Uyanma zamanı.',
      tzDate,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'wake_channel',
          'Wake Alarm',
          importance: Importance.max,
          priority: Priority.high,
          sound: RawResourceAndroidNotificationSound('alarm'),
          playSound: true,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  Future<void> _scheduleSleepAlarm(TimeOfDay time) async {
    final now = DateTime.now();
    DateTime scheduledDate = DateTime(
      now.year,
      now.month,
      now.day,
      time.hour,
      time.minute,
    );

    // Eğer alarm zamanı geçmişse, bir gün ekle
    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(Duration(days: 1));
    }

    final tz.TZDateTime tzDate = tz.TZDateTime.from(scheduledDate, tz.local);

    await flutterLocalNotificationsPlugin.zonedSchedule(
      0,
      'Uyku Saati',
      'Artık uyuma zamanı!',
      tzDate,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'sleep_channel',
          'Sleep Alarm',
          channelDescription: 'Uykuyu hatırlatır',
          importance: Importance.max,
          priority: Priority.high,
          playSound: true,
          sound: RawResourceAndroidNotificationSound('alarm'),
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }
}
