import 'package:flutter/material.dart';
import '../pages/home_page.dart';
import 'smoking_page.dart';
import 'alcohol_page.dart';
import 'social_media_page.dart';
import 'gaming_page.dart';
import 'caffeine_page.dart';
import 'other_page.dart';
import '../localization/localization.dart';

class AddictionsPage extends StatelessWidget {
  final String language;

  AddictionsPage({Key? key, required this.language}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final loc = Localization(language);

    final List<Map<String, dynamic>> addictions = [
      {
        'label': loc.addictionSmoking,
        'icon': Icons.smoking_rooms,
        'page': SmokingPage,
      },
      {
        'label': loc.addictionAlcohol,
        'icon': Icons.local_bar,
        'page': AlcoholPage,
      },
      {
        'label': loc.addictionSocialMedia,
        'icon': Icons.phone_android,
        'page': SocialMediaPage,
      },
      {
        'label': loc.addictionGaming,
        'icon': Icons.videogame_asset,
        'page': GamingPage,
      },
      {
        'label': loc.addictionCaffeine,
        'icon': Icons.coffee,
        'page': CaffeinePage,
      },
      {
        'label': loc.addictionOther,
        'icon': Icons.more_horiz,
        'page': OtherPage,
      },
    ];

    void _onAddictionSelected(BuildContext context, String addictionType) {
      Widget targetPage;

      switch (addictionType) {
        case 'Sigara':
        case 'Smoking':
          targetPage = SmokingPage(language: language);
          break;
        case 'Alkol':
        case 'Alcohol':
          targetPage = AlcoholPage(language: language);
          break;
        case 'Telefon / Sosyal Medya':
        case 'Phone / Social Media':
          targetPage = SocialMediaPage(language: language);
          break;
        case 'Oyun':
        case 'Gaming':
          targetPage = GamingPage(language: language);
          break;
        case 'Kafein':
        case 'Caffeine':
          targetPage = CaffeinePage(language: language);
          break;
        case 'Diğer':
        case 'Other':
          targetPage = OtherPage(language: language);
          break;
        default:
          return;
      }

      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => targetPage),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(loc.addictionsTitle),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => HomePage(language: language),
              ),
            );
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: addictions.length,
          itemBuilder: (context, index) {
            final item = addictions[index];
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: ElevatedButton.icon(
                icon: Icon(item['icon']),
                label: Text(item['label']),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  textStyle: TextStyle(fontSize: 18),
                ),
                onPressed: () => _onAddictionSelected(context, item['label']),
              ),
            );
          },
        ),
      ),
    );
  }
}
