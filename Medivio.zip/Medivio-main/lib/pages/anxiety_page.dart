import 'package:flutter/material.dart';
import '../localization/localization.dart';
import '../pages/home_page.dart';

class AnxietyPage extends StatefulWidget {
  final String language;

  AnxietyPage({required this.language});

  @override
  _AnxietyPageState createState() => _AnxietyPageState();
}

class _AnxietyPageState extends State<AnxietyPage> {
  late List<String> questions;
  late List<List<String>> answerOptions;
  late List<String> exercises;
  bool _showGroundingExercises = false;

  List<int?> answers = List.filled(7, null);

  String? _result;

  @override
  void initState() {
    super.initState();
    final loc = Localization(widget.language);
    questions = loc.ansietyQuestions;
    answerOptions = [
      loc.answerOption0,
      loc.answerOption1,
      loc.answerOption2,
      loc.answerOption3,
    ];
    exercises = [
      loc.groundingExercise1,
      loc.groundingExercise2,
      loc.groundingExercise3,
      loc.groundingExercise4,
      loc.groundingExercise5,
    ];
  }

  int _calculateScore() {
    int score = 0;
    for (var ans in answers) {
      if (ans != null) score += ans;
    }
    return score;
  }

  String _getResultMessage(int score, Localization loc) {
    if (score <= 4) return loc.minimalAnxiety;
    if (score <= 9) return loc.mildAnxiety;
    if (score <= 14) return loc.moderateAnxiety;
    return loc.severeAnxiety;
  }

  Widget _buildAdvice(String level, Localization loc) {
    if (level == loc.minimalAnxiety) {
      return _adviceColumn(loc.medicalInfoTitle, loc.minimalAnxietyTips);
    } else if (level == loc.mildAnxiety) {
      return _adviceColumn(loc.medicalInfoTitle, loc.mildAnxietyTips);
    } else if (level == loc.moderateAnxiety) {
      return _adviceColumn(loc.medicalInfoTitle, loc.moderateAnxietyTips);
    } else if (level == loc.severeAnxiety) {
      return _adviceColumn(loc.medicalInfoTitle, loc.severeAnxietyTips);
    } else {
      return SizedBox.shrink();
    }
  }

  Widget _adviceColumn(String title, List<String> points) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        SizedBox(height: 8),
        ...points.map((p) => Text(p)).toList(),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final loc = Localization(widget.language);

    return Scaffold(
      appBar: AppBar(
        title: Text(loc.anxietyTitle), // Lokasyondan başlık varsa onu kullan
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            // Ana sayfaya dön
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => HomePage(language: widget.language),
              ),
            );
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(loc.anxietyDescription, style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),

            // Butonlar yan yana, eşit genişlikte, aralarında boşluk
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _showGroundingExercises = false;
                      });
                    },
                    child: Text(loc.anxietyTestButton),
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _showGroundingExercises = true;
                      });
                    },
                    child: Text(loc.groundingExercises),
                  ),
                ),
              ],
            ),

            SizedBox(height: 20),

            Expanded(
              child: _showGroundingExercises
                  ? SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: exercises
                            .map(
                              (e) => Padding(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 8.0,
                                ),
                                child: Text(
                                  "- $e",
                                  style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: const Color.fromARGB(255, 0, 0, 0),
                                  ),
                                ),
                              ),
                            )
                            .toList(),
                      ),
                    )
                  : ListView.builder(
                      itemCount: questions.length,
                      itemBuilder: (context, index) {
                        return Card(
                          margin: EdgeInsets.symmetric(vertical: 6),
                          child: Padding(
                            padding: EdgeInsets.all(8),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  questions[index],
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 6),
                                for (int i = 0; i <= 3; i++)
                                  RadioListTile<int>(
                                    title: Text(
                                      widget.language == 'en'
                                          ? answerOptions[i][1]
                                          : answerOptions[i][0],
                                    ),
                                    value: i,
                                    groupValue: answers[index],
                                    onChanged: (value) {
                                      setState(() {
                                        answers[index] = value;
                                      });
                                    },
                                  ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),

            if (!_showGroundingExercises) ...[
              ElevatedButton(
                onPressed: answers.contains(null)
                    ? null
                    : () {
                        final score = _calculateScore();
                        final result = _getResultMessage(score, loc);
                        setState(() {
                          _result = result;
                        });
                        showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                            title: Text(loc.testResultTitle),
                            content: Text(
                              "${loc.totalScore}: $score\n${loc.status}: $result",
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context),
                                child: Text(loc.ok),
                              ),
                            ],
                          ),
                        );
                      },
                child: Text(loc.showResult),
              ),
              SizedBox(height: 20),
              if (_result != null) _buildAdvice(_result!, loc),
            ],
          ],
        ),
      ),
    );
  }
}
