import 'package:flutter/material.dart';

class CaffeinePage extends StatelessWidget {
  final String language;
  const CaffeinePage({required this.language});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kafein Bağımlılığı'),
        leading: BackButton(onPressed: () => Navigator.pop(context)),
      ),
      body: Center(child: Text('Kafein bağımlılığı sayfası - Dil: $language')),
    );
  }
}
