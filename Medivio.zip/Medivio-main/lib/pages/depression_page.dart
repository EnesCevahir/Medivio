import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../localization/localization.dart';
import '../widgets/base_page.dart';

import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../localization/localization.dart';
import '../pages/home_page.dart';

class DepressionPage extends StatefulWidget {
  final String language;

  DepressionPage({required this.language});

  @override
  _DepressionPageState createState() => _DepressionPageState();
}

class _DepressionPageState extends State<DepressionPage> {
  String? _selectedSmallTask;
  late List<String> _assignedTasks;

  @override
  void initState() {
    super.initState();
    final allTasks = Localization(widget.language).smallTasks;
    _assignedTasks = List<String>.from(allTasks)..shuffle();
    if (_assignedTasks.length > 30) {
      _assignedTasks = _assignedTasks.sublist(0, 30);
    }
  }

  void _selectSmallTask() {
    setState(() {
      _selectedSmallTask = (_assignedTasks..shuffle()).first;
    });
  }

  void _navigateTo(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  void _showMoodSelectionDialog() {
    showDialog(
      context: context,
      builder: (_) => MoodSelectionDialog(language: widget.language),
    );
  }

  void _showAboutDialog() {
    final loc = Localization(widget.language);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(loc.aboutDepression),
        content: SingleChildScrollView(
          child: Text(loc.depressionInfoText, style: TextStyle(fontSize: 16)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(loc.close),
          ),
        ],
      ),
    );
  }

  void _openEmergencyLink() async {
    final url = Uri.parse('https://www.youtube.com/shorts/Xp-VM8Z9wIQ');
    if (await canLaunchUrl(url)) {
      await launchUrl(
        url,
        mode: LaunchMode.externalApplication, // Bunu EKLE!
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(Localization(widget.language).couldNotOpenLink)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final loc = Localization(widget.language);

    return Scaffold(
      appBar: AppBar(
        title: Text(loc.depressionTitle),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => HomePage(language: widget.language),
              ),
            );
          },
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                loc.menu,
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text(loc.home),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => HomePage(language: widget.language),
                  ),
                );
              },
            ),
            // İstersen diğer menü maddeleri buraya eklenebilir
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Açıklama metni üstte
            SizedBox(height: 16),

            // Ana seçenekler liste butonları olarak
            Expanded(
              child: ListView(
                children: [
                  ElevatedButton.icon(
                    icon: Icon(Icons.self_improvement),
                    label: Text(loc.breathingExercise),
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      textStyle: TextStyle(fontSize: 18),
                    ),
                    onPressed: () => _navigateTo(
                      context,
                      Scaffold(
                        appBar: AppBar(title: Text(loc.breathingExercise)),
                        body: BreathingExerciseWidget(
                          language: widget.language,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 10),

                  ElevatedButton.icon(
                    icon: Icon(Icons.book),
                    label: Text(loc.dailyJournal),
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      textStyle: TextStyle(fontSize: 18),
                    ),
                    onPressed: () => _navigateTo(
                      context,
                      Scaffold(
                        appBar: AppBar(title: Text(loc.dailyJournal)),
                        body: DailyJournalWidget(language: widget.language),
                      ),
                    ),
                  ),
                  SizedBox(height: 10),

                  ElevatedButton.icon(
                    icon: Icon(Icons.task),
                    label: Text(loc.giveMeTask),
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      textStyle: TextStyle(fontSize: 18),
                    ),
                    onPressed: _selectSmallTask,
                  ),
                  SizedBox(height: 10),

                  ElevatedButton.icon(
                    icon: Icon(Icons.mood),
                    label: Text(loc.mood),
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      textStyle: TextStyle(fontSize: 18),
                    ),
                    onPressed: _showMoodSelectionDialog,
                  ),
                  SizedBox(height: 10),

                  ElevatedButton.icon(
                    icon: Icon(Icons.history),
                    label: Text(loc.moodHistory),
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      textStyle: TextStyle(fontSize: 18),
                    ),
                    onPressed: () => _navigateTo(
                      context,
                      Scaffold(
                        appBar: AppBar(title: Text(loc.moodHistory)),
                        body: MoodHistoryWidget(language: widget.language),
                      ),
                    ),
                  ),
                  SizedBox(height: 10),

                  ElevatedButton.icon(
                    icon: Icon(Icons.info),
                    label: Text(loc.aboutDepression),
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      textStyle: TextStyle(fontSize: 18),
                    ),
                    onPressed: _showAboutDialog,
                  ),
                  SizedBox(height: 10),

                  ElevatedButton.icon(
                    icon: Icon(Icons.health_and_safety),
                    label: Text(loc.emergencySupport),
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      textStyle: TextStyle(fontSize: 18),
                    ),
                    onPressed: _openEmergencyLink,
                  ),
                ],
              ),
            ),

            // Alt kısımda seçilen küçük görev metni
            if (_selectedSmallTask != null)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                child: Text(
                  _selectedSmallTask!,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// Diğer widgetlar (MoodSelectionDialog, MoodHistoryWidget, DailyJournalWidget, BreathingExerciseWidget) aynen korunabilir veya sen istersen ayrı dosyaya taşıyabilirsin.

// Ruh hali seçimi dialogu
class MoodSelectionDialog extends StatefulWidget {
  final String language;
  MoodSelectionDialog({required this.language});

  @override
  _MoodSelectionDialogState createState() => _MoodSelectionDialogState();
}

class _MoodSelectionDialogState extends State<MoodSelectionDialog> {
  int? _selectedMoodIndex;

  final List<String> moods = ['😞', '😐', '🙂', '😄', '🤩'];

  void _saveMood(int index) async {
    final loc = Localization(widget.language);
    final prefs = await SharedPreferences.getInstance();
    final now = DateTime.now().toIso8601String();

    final mood = {
      'emoji': moods[index],
      'desc': loc.moodLabels[index],
      'date': now,
    };

    final savedList = prefs.getStringList('saved_moods') ?? [];
    savedList.insert(0, jsonEncode(mood));
    await prefs.setStringList('saved_moods', savedList);

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final loc = Localization(widget.language);
    final descriptions = loc.moodLabels;

    return AlertDialog(
      title: Text(loc.moodSelectTitle),
      content: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(moods.length, (i) {
          return GestureDetector(
            onTap: () => _saveMood(i),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(moods[i], style: TextStyle(fontSize: 32)),
                SizedBox(height: 4),
                Text(descriptions[i], style: TextStyle(fontSize: 12)),
              ],
            ),
          );
        }),
      ),
    );
  }
}

// Ruh hali geçmişi widget'ı
class MoodHistoryWidget extends StatefulWidget {
  final String language;
  MoodHistoryWidget({required this.language});

  @override
  _MoodHistoryWidgetState createState() => _MoodHistoryWidgetState();
}

class _MoodHistoryWidgetState extends State<MoodHistoryWidget> {
  List<Map<String, dynamic>> _moodHistory = [];

  @override
  void initState() {
    super.initState();
    _loadMoodHistory();
  }

  Future<void> _loadMoodHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('saved_moods') ?? [];
    final parsed = saved
        .map((e) => jsonDecode(e) as Map<String, dynamic>)
        .toList(growable: true);

    setState(() {
      _moodHistory = parsed;
    });
  }

  Future<void> _deleteMood(int index) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _moodHistory.removeAt(index);
      prefs.setStringList(
        'saved_moods',
        _moodHistory.map((e) => jsonEncode(e)).toList(),
      );
    });
  }

  void _confirmDelete(int index) {
    final loc = Localization(widget.language);

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(loc.confirmDelete),
        content: Text(loc.confirmDeleteMsg),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(loc.cancel),
          ),
          TextButton(
            onPressed: () {
              _deleteMood(index);
              Navigator.pop(context);
            },
            child: Text(loc.delete),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final loc = Localization(widget.language);

    if (_moodHistory.isEmpty) {
      return Center(child: Text(loc.noMoodHistory));
    }

    return ListView.builder(
      itemCount: _moodHistory.length,
      itemBuilder: (context, index) {
        final mood = _moodHistory[index];
        final formattedDate = DateTime.parse(mood['date']).toLocal();
        final dateStr =
            '${formattedDate.day}.${formattedDate.month}.${formattedDate.year} ${formattedDate.hour}:${formattedDate.minute.toString().padLeft(2, '0')}';

        return Card(
          margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: ListTile(
            leading: Text(mood['emoji'], style: TextStyle(fontSize: 32)),
            title: Text(mood['desc']),
            subtitle: Text(dateStr),
            trailing: IconButton(
              icon: Icon(Icons.delete, color: Colors.red),
              onPressed: () => _confirmDelete(index),
            ),
          ),
        );
      },
    );
  }
}

// Günlük tutma veri modeli
class JournalEntry {
  final String text;
  final DateTime date;

  JournalEntry({required this.text, required this.date});

  Map<String, dynamic> toMap() => {
    'text': text,
    'date': date.toIso8601String(),
  };

  factory JournalEntry.fromMap(Map<String, dynamic> map) =>
      JournalEntry(text: map['text'], date: DateTime.parse(map['date']));

  String toJson() => jsonEncode(toMap());

  factory JournalEntry.fromJson(String jsonStr) =>
      JournalEntry.fromMap(jsonDecode(jsonStr));
}

// Günlük tutma widget
class DailyJournalWidget extends StatefulWidget {
  final String language;
  DailyJournalWidget({required this.language})
    : super(key: ValueKey('daily_journal_widget'));

  @override
  DailyJournalWidgetState createState() => DailyJournalWidgetState();
}

class DailyJournalWidgetState extends State<DailyJournalWidget> {
  final TextEditingController _controller = TextEditingController();
  List<JournalEntry> _entries = [];

  @override
  void initState() {
    super.initState();
    _loadEntries();
  }

  Future<void> _loadEntries() async {
    final prefs = await SharedPreferences.getInstance();
    final storedList = prefs.getStringList('daily_journal_entries');

    if (storedList != null) {
      List<JournalEntry> loadedEntries = [];
      bool hasError = false;

      for (var item in storedList) {
        try {
          loadedEntries.add(JournalEntry.fromJson(item));
        } catch (_) {
          hasError = true;
        }
      }

      if (hasError) {
        // Hatalı girdiler temizlendi, tekrar kayıt
        final cleanList = loadedEntries.map((e) => e.toJson()).toList();
        await prefs.setStringList('daily_journal_entries', cleanList);
      }

      setState(() {
        _entries = loadedEntries;
      });
    }
  }

  Future<void> _addEntry() async {
    final text = _controller.text.trim();
    if (text.isNotEmpty) {
      final newEntry = JournalEntry(text: text, date: DateTime.now());

      setState(() {
        _entries.insert(0, newEntry);
        _controller.clear();
      });

      final prefs = await SharedPreferences.getInstance();
      final jsonList = _entries.map((e) => e.toJson()).toList();
      await prefs.setStringList('daily_journal_entries', jsonList);
    }
  }

  Future<void> _deleteEntry(int index) async {
    setState(() {
      _entries.removeAt(index);
    });

    final prefs = await SharedPreferences.getInstance();
    final jsonList = _entries.map((e) => e.toJson()).toList();
    await prefs.setStringList('daily_journal_entries', jsonList);
  }

  @override
  Widget build(BuildContext context) {
    final loc = Localization(widget.language);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(
          loc.journalPrompt,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 10),
        TextField(
          controller: _controller,
          maxLines: 3,
          decoration: InputDecoration(
            border: OutlineInputBorder(),
            hintText: loc.journalHint,
          ),
        ),
        SizedBox(height: 10),
        ElevatedButton(onPressed: _addEntry, child: Text(loc.save)),
        SizedBox(height: 20),
        if (_entries.isEmpty)
          Center(child: Text(loc.noJournalEntries))
        else
          ..._entries.asMap().entries.map((entry) {
            final idx = entry.key;
            final e = entry.value;
            final formattedDate =
                "${e.date.day.toString().padLeft(2, '0')}/${e.date.month.toString().padLeft(2, '0')}/${e.date.year} "
                "${e.date.hour.toString().padLeft(2, '0')}:${e.date.minute.toString().padLeft(2, '0')}";

            return Card(
              margin: EdgeInsets.symmetric(vertical: 5),
              child: ListTile(
                leading: Icon(Icons.book),
                title: Text(e.text),
                subtitle: Text(
                  formattedDate,
                  style: TextStyle(color: Colors.black54),
                ),
                trailing: IconButton(
                  icon: Icon(Icons.delete, color: Colors.red),
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: Text(loc.deleteConfirmationTitle),
                        content: Text(loc.deleteConfirmationMsg),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text(loc.cancel),
                          ),
                          TextButton(
                            onPressed: () {
                              _deleteEntry(idx);
                              Navigator.pop(context);
                            },
                            child: Text(loc.delete),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            );
          }).toList(),
      ],
    );
  }
}

// Nefes egzersizi widget
class BreathingExerciseWidget extends StatefulWidget {
  final String language; // Dışarıdan dil bilgisini alacak

  BreathingExerciseWidget({required this.language}); // Constructor eklendi

  @override
  _BreathingExerciseWidgetState createState() =>
      _BreathingExerciseWidgetState();
}

class _BreathingExerciseWidgetState extends State<BreathingExerciseWidget> {
  late List<_BreathPhase> _phases;
  int _currentPhaseIndex = 0;
  int _secondsLeft = 0;
  Timer? _timer;
  bool _isRunning = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final loc = Localization(widget.language);
    _phases = [
      _BreathPhase(loc.breathe, 4),
      _BreathPhase(loc.holdBreath, 7),
      _BreathPhase(loc.exhale, 8),
    ];
    _secondsLeft = _phases[_currentPhaseIndex].duration;
  }

  void _resetExercise() {
    _timer?.cancel();
    _isRunning = false;
    _currentPhaseIndex = 0;
    _secondsLeft = _phases[_currentPhaseIndex].duration;
    setState(() {});
  }

  void _startExercise() {
    if (_isRunning) return;

    _isRunning = true;
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_secondsLeft > 1) {
        setState(() {
          _secondsLeft--;
        });
      } else {
        setState(() {
          if (_currentPhaseIndex < _phases.length - 1) {
            _currentPhaseIndex++;
          } else {
            _currentPhaseIndex = 0;
          }
          _secondsLeft = _phases[_currentPhaseIndex].duration;
        });
      }
    });
  }

  void _stopExercise() {
    _timer?.cancel();
    _isRunning = false;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final phase = _phases[_currentPhaseIndex];

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          phase.name,
          style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 20),
        Text(
          '$_secondsLeft',
          style: TextStyle(fontSize: 80, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 40),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: _isRunning ? null : _startExercise,
              child: Text(Localization(widget.language).start),
            ),
            SizedBox(width: 20),
            ElevatedButton(
              onPressed: _isRunning ? _stopExercise : null,
              child: Text(Localization(widget.language).stop),
            ),
            SizedBox(width: 20),
            ElevatedButton(
              onPressed: _resetExercise,
              child: Text(Localization(widget.language).reset),
            ),
          ],
        ),
      ],
    );
  }
}

class _BreathPhase {
  final String name;
  final int duration;

  _BreathPhase(this.name, this.duration);
}
