import 'package:flutter/material.dart';

class AlcoholPage extends StatelessWidget {
  final String language;
  const AlcoholPage({required this.language});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Alkol Bağımlılığı'),
        leading: BackButton(onPressed: () => Navigator.pop(context)),
      ),
      body: Center(child: Text('Alkol bağımlığı sayfası - Dil: $language')),
    );
  }
}
