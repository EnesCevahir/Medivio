import 'package:flutter/material.dart';
import '../localization/localization.dart';
import '../services/daily_task_manager.dart';
import '../services/streak_manager.dart';
import 'package:permission_handler/permission_handler.dart';

class HomePage extends StatefulWidget {
  final String language;

  const HomePage({required this.language, Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Localization loc;
  String dailyTask = '';
  bool taskCompleted = false;
  int streakCount = 0;

  @override
  void initState() {
    super.initState();
    loc = Localization(widget.language);

    _checkNotificationPermission(); // İzin kontrolü burada çağrılıyor
    _loadDailyTask();
    _updateStreak();
  }

  Future<void> _checkNotificationPermission() async {
    final status = await Permission.notification.status;
    if (!status.isGranted) {
      // İzin yoksa kullanıcıya bilgi verip ayarlar sayfasına yönlendirme yap
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: Text(loc.permissionNeededTitle ?? 'Bildirim İzni Gerekli'),
            content: Text(
              loc.permissionNeededMessage ??
                  'Bildirim gönderebilmemiz için izin vermeniz gerekiyor. Ayarlar sayfasına yönlendirileceksiniz.',
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.pushNamed(
                    context,
                    '/settings',
                  ); // İzinler sayfanın rotası
                },
                child: Text(loc.goToSettings ?? 'Ayarlar'),
              ),
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text(loc.cancel ?? 'İptal'),
              ),
            ],
          ),
        );
      });
    }
  }

  Future<void> _loadDailyTask() async {
    final task = await DailyTaskManager.getTodayTask(loc);
    final isCompleted = await DailyTaskManager.isTaskCompletedToday();

    setState(() {
      dailyTask = task;
      taskCompleted = isCompleted;
    });
  }

  Future<void> _updateStreak() async {
    final streak = await StreakManager.updateStreak();
    setState(() {
      streakCount = streak;
    });

    if (streak == 3 || streak == 7) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(loc.streakCongrats(streak)),
          duration: Duration(seconds: 3),
        ),
      );
    }
  }

  void _markTaskCompleted() async {
    await DailyTaskManager.markTaskAsCompleted();
    setState(() {
      taskCompleted = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(loc.welcome),
        automaticallyImplyLeading: false,
      ),
      body: Center(
        child: ListView(
          shrinkWrap: true,
          padding: EdgeInsets.symmetric(horizontal: 40),
          children: [
            // Günlük görev bölümü
            Text(
              loc.dailyTaskTitle,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              dailyTask.isNotEmpty ? dailyTask : loc.loading,
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 10),
            ElevatedButton.icon(
              icon: Icon(
                taskCompleted ? Icons.check_circle : Icons.check_circle_outline,
              ),
              label: Text(taskCompleted ? loc.taskCompleted : loc.completeTask),
              onPressed: taskCompleted ? null : _markTaskCompleted,
            ),
            Divider(height: 40),

            // Diğer butonlar...
            ElevatedButton.icon(
              icon: Icon(Icons.local_fire_department),
              label: Text(loc.stressAndAnxiety),
              onPressed: () {
                Navigator.pushNamed(context, '/stress');
              },
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
                textStyle: TextStyle(fontSize: 18),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton.icon(
              icon: Icon(Icons.bedtime),
              label: Text(loc.sleepTitle),
              onPressed: () {
                Navigator.pushNamed(context, '/sleep');
              },
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
                textStyle: TextStyle(fontSize: 18),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton.icon(
              icon: Icon(Icons.fastfood),
              label: Text(loc.nutritionTitle),
              onPressed: () {
                Navigator.pushNamed(context, '/nutrition');
              },
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
                textStyle: TextStyle(fontSize: 18),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton.icon(
              icon: Icon(Icons.sentiment_satisfied),
              label: Text(loc.depressionTitleShort),
              onPressed: () {
                Navigator.pushNamed(context, '/depression');
              },
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
                textStyle: TextStyle(fontSize: 18),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton.icon(
              icon: Icon(Icons.add_circle),
              label: Text(loc.addictionsTitle),
              onPressed: () {
                Navigator.pushNamed(context, '/addictions');
              },
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
                textStyle: TextStyle(fontSize: 18),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton.icon(
              icon: Icon(Icons.settings),
              label: Text(loc.settingsTitle),
              onPressed: () {
                Navigator.pushNamed(context, '/settings');
              },
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
                textStyle: TextStyle(fontSize: 18),
              ),
            ),
            SizedBox(height: 40),

            // Streak göstergesi
            Text(
              loc.streakCount(streakCount),
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
