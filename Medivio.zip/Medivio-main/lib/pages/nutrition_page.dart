import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../localization/localization.dart';
import '../widgets/base_page.dart';
import '../services/notification_service.dart'; // Bildirim servisiniz varsa

class NutritionPage extends StatefulWidget {
  final String language;
  NutritionPage({required this.language});

  @override
  _NutritionPageState createState() => _NutritionPageState();
}

class _NutritionPageState extends State<NutritionPage> {
  @override
  void initState() {
    super.initState();
    _fixCorruptedDailyMeals();
  }

  Future<void> _fixCorruptedDailyMeals() async {
    final prefs = await SharedPreferences.getInstance();
    final rawData = prefs.get('daily_meals');
    if (rawData is! List<String>) {
      await prefs.remove('daily_meals');
      debugPrint('Bozuk daily_meals verisi silindi');
    }
  }

  @override
  Widget build(BuildContext context) {
    final loc = Localization(widget.language);

    return Scaffold(
      appBar: AppBar(
        title: Text(loc.nutrition),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            // Anasayfaya geri dön
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text(loc.nutritionDesc, style: TextStyle(fontSize: 18)),
            SizedBox(height: 24),

            ElevatedButton(
              onPressed: () => showDialog(
                context: context,
                builder: (_) => BMIDialog(language: widget.language),
              ),
              child: Text(loc.bmiCalculator),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
              ),
            ),
            SizedBox(height: 12),

            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => BMIHistoryPage(language: widget.language),
                  ),
                );
              },
              child: Text(loc.bmiHistory),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
              ),
            ),
            SizedBox(height: 12),

            ElevatedButton(
              onPressed: () => showDialog(
                context: context,
                builder: (_) => DailyMealsDialog(language: widget.language),
              ),
              child: Text(loc.dailyMeals),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
              ),
            ),
            SizedBox(height: 12),

            ElevatedButton(
              onPressed: () => showDialog(
                context: context,
                builder: (_) => WaterReminderDialog(language: widget.language),
              ),
              child: Text(loc.waterReminder),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
              ),
            ),
            SizedBox(height: 12),

            ElevatedButton(
              onPressed: () => showDialog(
                context: context,
                builder: (_) => MealHistoryDialog(language: widget.language),
              ),
              child: Text(loc.showSavedMeals),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
              ),
            ),
            SizedBox(height: 12),

            ElevatedButton.icon(
              icon: Icon(Icons.local_hospital),
              label: Text(loc.vitaminsTitle),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => VitaminInfoPage(language: widget.language),
                  ),
                );
              },

              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
                textStyle: TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ------------------------------------------------------------
// DailyMealsDialog - Günlük Yemek Kaydı
// ------------------------------------------------------------

class DailyMealsDialog extends StatefulWidget {
  final String language;
  DailyMealsDialog({required this.language});

  @override
  _DailyMealsDialogState createState() => _DailyMealsDialogState();
}

class _DailyMealsDialogState extends State<DailyMealsDialog> {
  final _mealController = TextEditingController();
  final _calorieController = TextEditingController();
  String? _savedMessage;

  List<Map<String, dynamic>> _todayMeals = [];
  int _totalCalories = 0;

  @override
  void initState() {
    super.initState();
    _loadTodayMeals();
  }

  Future<void> _loadTodayMeals() async {
    final prefs = await SharedPreferences.getInstance();
    final savedList = prefs.getStringList('daily_meals') ?? [];

    final today = DateTime.now();
    List<Map<String, dynamic>> mealsToday = [];

    for (var item in savedList) {
      try {
        final decoded = jsonDecode(item);
        if (decoded is Map<String, dynamic>) {
          DateTime date =
              DateTime.tryParse(decoded['date'] ?? '') ?? DateTime.now();

          // Sadece bugün olanları al
          if (date.year == today.year &&
              date.month == today.month &&
              date.day == today.day) {
            mealsToday.add(decoded);
          }
        }
      } catch (_) {}
    }

    setState(() {
      _todayMeals = mealsToday;
      _calculateTotalCalories();
    });
  }

  void _calculateTotalCalories() {
    int total = 0;
    for (var meal in _todayMeals) {
      final calStr = meal['calories'] ?? '0';
      final cal = int.tryParse(calStr) ?? 0;
      total += cal;
    }
    _totalCalories = total;
  }

  Future<void> _saveMeal() async {
    final prefs = await SharedPreferences.getInstance();

    final meal = {
      'meal': _mealController.text.trim(),
      'calories': _calorieController.text.trim(),
      'date': DateTime.now().toIso8601String(),
    };

    List<String> dailyMealsList = prefs.getStringList('daily_meals') ?? [];
    dailyMealsList.insert(0, jsonEncode(meal));
    await prefs.setStringList('daily_meals', dailyMealsList);

    _mealController.clear();
    _calorieController.clear();

    await _loadTodayMeals();

    setState(() {
      _savedMessage = 'Kaydedildi!';
    });
  }

  @override
  Widget build(BuildContext context) {
    final loc = Localization(widget.language);

    return AlertDialog(
      title: Text(loc.dailyMeals),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _mealController,
              decoration: InputDecoration(labelText: loc.meal), // Örnek öğün
            ),
            TextField(
              controller: _calorieController,
              decoration: InputDecoration(labelText: 'Kalori'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16),
            ElevatedButton(onPressed: _saveMeal, child: Text(loc.save)),

            if (_savedMessage != null) ...[
              SizedBox(height: 10),
              Text(_savedMessage!, style: TextStyle(color: Colors.green)),
            ],

            SizedBox(height: 20),
            Text(
              'Bugünkü toplam kalori: $_totalCalories',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(loc.close),
        ),
      ],
    );
  }
}

// ------------------------------------------------------------
// MealHistoryDialog - Yemek Geçmişi
// ------------------------------------------------------------

class MealHistoryDialog extends StatefulWidget {
  final String language;
  MealHistoryDialog({required this.language});

  @override
  _MealHistoryDialogState createState() => _MealHistoryDialogState();
}

class _MealHistoryDialogState extends State<MealHistoryDialog> {
  List<Map<String, dynamic>> _mealsList = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadMeals();
  }

  Future<void> _loadMeals() async {
    final prefs = await SharedPreferences.getInstance();
    final savedList = prefs.getStringList('daily_meals') ?? [];

    List<Map<String, dynamic>> loaded = [];
    for (var item in savedList) {
      try {
        final decoded = jsonDecode(item);
        if (decoded is Map<String, dynamic>) {
          loaded.add(decoded);
        }
      } catch (_) {}
    }

    setState(() {
      _mealsList = loaded;
      _loading = false;
    });
  }

  Future<void> _deleteMeal(int index) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> savedList = prefs.getStringList('daily_meals') ?? [];

    if (index < 0 || index >= savedList.length) return;

    savedList.removeAt(index);
    await prefs.setStringList('daily_meals', savedList);

    await _loadMeals();
  }

  @override
  Widget build(BuildContext context) {
    final loc = Localization(widget.language);

    if (_loading) {
      return AlertDialog(
        title: Text(loc.dailyMeals),
        content: Center(child: CircularProgressIndicator()),
      );
    }

    return AlertDialog(
      title: Text(loc.dailyMeals),
      content: SizedBox(
        width: double.maxFinite,
        height: MediaQuery.of(context).size.height * 0.5,
        child: _mealsList.isEmpty
            ? Center(child: Text(loc.noMealsSaved))
            : ListView.builder(
                itemCount: _mealsList.length,
                itemBuilder: (context, index) {
                  final meal = _mealsList[index];
                  final date =
                      DateTime.tryParse(meal['date'] ?? '') ?? DateTime.now();
                  final formattedDate =
                      '${date.day}.${date.month}.${date.year}';

                  final mealText = meal['meal'] ?? '';
                  final calories = meal['calories'] ?? '';

                  return ListTile(
                    title: Text('$mealText'),
                    subtitle: Text('Kalori: $calories\nTarih: $formattedDate'),
                    trailing: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      tooltip: 'Sil',
                      onPressed: () async {
                        final confirm = await showDialog<bool>(
                          context: context,
                          builder: (_) => AlertDialog(
                            title: Text('Onay'),
                            content: Text(
                              'Bu öğünü silmek istediğinize emin misiniz?',
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context, false),
                                child: Text('İptal'),
                              ),
                              TextButton(
                                onPressed: () => Navigator.pop(context, true),
                                child: Text('Sil'),
                              ),
                            ],
                          ),
                        );

                        if (confirm == true) {
                          await _deleteMeal(index);
                        }
                      },
                    ),
                  );
                },
              ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(loc.close),
        ),
      ],
    );
  }
}

// ------------------------------------------------------------
// WaterReminderDialog - Su Hatırlatma
// ------------------------------------------------------------

class WaterReminderDialog extends StatefulWidget {
  final String language;
  WaterReminderDialog({required this.language});

  @override
  _WaterReminderDialogState createState() => _WaterReminderDialogState();
}

class _WaterReminderDialogState extends State<WaterReminderDialog> {
  int _glassCount = 0;
  int? _dailyGoal;
  final _goalController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadGlassCountAndGoal();
  }

  Future<void> _loadGlassCountAndGoal() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _glassCount = prefs.getInt('glass_count') ?? 0;
      _dailyGoal = prefs.getInt('daily_goal');
      if (_dailyGoal != null) _goalController.text = _dailyGoal.toString();
    });
  }

  Future<void> _incrementGlass() async {
    if (_dailyGoal == null) {
      _showSetGoalDialog();
      return;
    }
    if (_glassCount < _dailyGoal!) {
      setState(() => _glassCount++);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('glass_count', _glassCount);
    }
  }

  Future<void> _resetCount() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('glass_count');
    await prefs.remove('daily_goal');

    setState(() {
      _glassCount = 0;
      _dailyGoal = null;
      _goalController.clear();
    });
  }

  void _showSetGoalDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Günlük Hedef Bardak Sayısı'),
        content: TextField(
          controller: _goalController,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(hintText: 'Örnek: 8'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('İptal'),
          ),
          ElevatedButton(
            onPressed: () {
              final input = int.tryParse(_goalController.text);
              if (input != null && input > 0) {
                SharedPreferences.getInstance().then((prefs) async {
                  await prefs.setInt('daily_goal', input);
                  await prefs.setInt('glass_count', 0);
                  setState(() {
                    _dailyGoal = input;
                    _glassCount = 0;
                  });
                  Navigator.pop(context);
                });
              }
            },
            child: Text('Kaydet'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final loc = Localization(widget.language);

    return AlertDialog(
      title: Text(loc.waterReminder),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_dailyGoal == null) ...[
            Text('Lütfen günlük su hedefinizi belirleyin.'),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: _showSetGoalDialog,
              child: Text('Hedef Belirle'),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ] else ...[
            Text('${loc.glassesDrank}: $_glassCount / $_dailyGoal'),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _incrementGlass,
              child: Text(loc.drinkOneGlass),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 14),
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: _resetCount,
              icon: Icon(Icons.delete),
              label: Text(loc.reset),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                padding: EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(loc.close),
        ),
      ],
    );
  }
}

// ------------------------------------------------------------
// BMIDialog - BMI Hesaplama
// ------------------------------------------------------------

class BMIDialog extends StatefulWidget {
  final String language;
  BMIDialog({required this.language});

  @override
  _BMIDialogState createState() => _BMIDialogState();
}

class _BMIDialogState extends State<BMIDialog> {
  final _heightController = TextEditingController();
  final _weightController = TextEditingController();
  String? _result;

  String _getBMIDescription(double bmi, Localization loc) {
    if (bmi < 18.5) return '${loc.bmiUnderweight}\n${loc.bmiUnderweightInfo}';
    if (bmi < 25) return '${loc.bmiNormal}\n${loc.bmiNormalInfo}';
    if (bmi < 30) return '${loc.bmiOverweight}\n${loc.bmiOverweightInfo}';
    return '${loc.bmiObese}\n${loc.bmiObeseInfo}';
  }

  Future<void> _calculateBMI() async {
    final loc = Localization(widget.language);
    final height = double.tryParse(_heightController.text);
    final weight = double.tryParse(_weightController.text);

    if (height == null || weight == null || height <= 0) {
      setState(() => _result = loc.invalidInput);
      return;
    }

    final bmi = weight / ((height / 100) * (height / 100));
    final bmiRounded = bmi.toStringAsFixed(1);
    final description = _getBMIDescription(bmi, loc);

    final prefs = await SharedPreferences.getInstance();
    final bmiData = jsonEncode({
      'bmi': bmiRounded,
      'date': DateTime.now().toIso8601String(),
    });
    List<String> bmiList = prefs.getStringList('bmi_history') ?? [];
    bmiList.insert(0, bmiData);
    await prefs.setStringList('bmi_history', bmiList);

    setState(() {
      _result = '${loc.bmiResult}: $bmiRounded\n$description';
    });
  }

  @override
  Widget build(BuildContext context) {
    final loc = Localization(widget.language);

    return AlertDialog(
      title: Text(loc.bmiCalculator),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _heightController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: loc.enterHeight),
          ),
          TextField(
            controller: _weightController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: loc.enterWeight),
          ),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: _calculateBMI,
            child: Text(loc.calculate),
            style: ElevatedButton.styleFrom(
              padding: EdgeInsets.symmetric(vertical: 14),
            ),
          ),

          if (_result != null) ...[
            SizedBox(height: 16),
            Text(_result!, style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(loc.close),
        ),
      ],
    );
  }
}

// ------------------------------------------------------------
// BMIHistoryPage - BMI Geçmişi
// ------------------------------------------------------------

class BMIHistoryPage extends StatefulWidget {
  final String language;
  BMIHistoryPage({required this.language});

  @override
  _BMIHistoryPageState createState() => _BMIHistoryPageState();
}

class _BMIHistoryPageState extends State<BMIHistoryPage> {
  List<Map<String, dynamic>> _bmiList = [];

  @override
  void initState() {
    super.initState();
    _loadBMIHistory();
  }

  Future<void> _loadBMIHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final savedList = prefs.getStringList('bmi_history') ?? [];
    final parsed = savedList
        .map((e) => jsonDecode(e) as Map<String, dynamic>)
        .toList();

    setState(() {
      _bmiList = parsed;
    });
  }

  @override
  Widget build(BuildContext context) {
    final loc = Localization(widget.language);

    return Scaffold(
      appBar: AppBar(
        title: Text(loc.bmiHistory),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.delete),
            tooltip: loc.clearHistory,
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.remove('bmi_history');
              setState(() {
                _bmiList.clear();
              });
            },
          ),
        ],
      ),
      body: _bmiList.isEmpty
          ? Center(child: Text(loc.noBmiHistory))
          : ListView.builder(
              itemCount: _bmiList.length,
              itemBuilder: (context, index) {
                final item = _bmiList[index];
                final bmi = item['bmi'];
                final date =
                    DateTime.tryParse(item['date'] ?? '') ?? DateTime.now();
                final formattedDate =
                    '${date.day}.${date.month}.${date.year} ${date.hour}:${date.minute.toString().padLeft(2, '0')}';

                return ListTile(
                  title: Text('BMI: $bmi'),
                  subtitle: Text('Tarih: $formattedDate'),
                );
              },
            ),
    );
  }
}

class VitaminInfoPage extends StatelessWidget {
  final String language;

  const VitaminInfoPage({required this.language});

  @override
  Widget build(BuildContext context) {
    final loc = Localization(language);

    return Scaffold(
      appBar: AppBar(title: Text(loc.vitaminsTitle)),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          Text(loc.vitaminsIntro, style: TextStyle(fontSize: 18)),
          SizedBox(height: 24),
          _buildCard('Vitamin D --- ', loc.vitaminDInfo),
          _buildCard('Vitamin B12 --', loc.vitaminB12Info),
          _buildCard('Vitamin C -', loc.vitaminCInfo),
          _buildCard('Vitamin A --', loc.vitaminAInfo),
          _buildCard('Vitamin E', loc.vitaminEInfo),
          _buildCard('Vitamin K', loc.vitaminKInfo),
          _buildCard('Folat', loc.folateInfo),
          _buildCard('Vitamin B6', loc.vitaminB6Info),
          _buildCard('Biotin', loc.biotinInfo),
          // Diğer vitaminleri de ekleyebilirsin.
        ],
      ),
    );
  }

  Widget _buildCard(String title, String description) {
    return Card(
      margin: EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
            ),
            SizedBox(height: 8),
            Text(description),
          ],
        ),
      ),
    );
  }
}
