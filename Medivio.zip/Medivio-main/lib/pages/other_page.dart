import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class OtherPage extends StatefulWidget {
  final String language;
  const OtherPage({required this.language});

  @override
  _OtherPageState createState() => _OtherPageState();
}

class PlanModel {
  String dependency;
  String effects;
  String goal;
  String triggers;
  String alternatives;
  String customPlan;
  bool isCompleted;

  PlanModel({
    required this.dependency,
    required this.effects,
    required this.goal,
    required this.triggers,
    required this.alternatives,
    required this.customPlan,
    this.isCompleted = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'dependency': dependency,
      'effects': effects,
      'goal': goal,
      'triggers': triggers,
      'alternatives': alternatives,
      'customPlan': customPlan,
      'isCompleted': isCompleted,
    };
  }

  factory PlanModel.fromMap(Map<String, dynamic> map) {
    return PlanModel(
      dependency: map['dependency'] ?? '',
      effects: map['effects'] ?? '',
      goal: map['goal'] ?? '',
      triggers: map['triggers'] ?? '',
      alternatives: map['alternatives'] ?? '',
      customPlan: map['customPlan'] ?? '',
      isCompleted: map['isCompleted'] ?? false,
    );
  }
}

class _OtherPageState extends State<OtherPage> {
  final _dependencyController = TextEditingController();
  final _effectsController = TextEditingController();
  final _goalController = TextEditingController();
  final _triggersController = TextEditingController();
  final _alternativesController = TextEditingController();
  final _customPlanController = TextEditingController();

  PlanModel? _loadedPlan;

  final String generalInfo = '''
Bağımlılık, kişinin istemediği hâlde sürdürdüğü ve zamanla hayat kalitesini olumsuz etkileyen bir alışkanlıktır.
Bu uygulama, kendi bağımlılığını tanıman ve bu süreci yönetmen için seninle birlikte ilerler.

🔹 Küçük ama sürdürülebilir adımlar at.
🔹 Zorlandığında bile geri dönmek için planın hazır olsun.
🔹 Unutma, bu bir yarış değil. Süreç kişisel ve senin kontrolünde.
🔹 Her gün bir önceki halinden daha iyi olmayı hedefle.
''';

  @override
  void initState() {
    super.initState();
    _loadPlan();
  }

  void _loadPlan() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('user_plan');
    if (data != null) {
      final plan = PlanModel.fromMap(jsonDecode(data));
      setState(() {
        _loadedPlan = plan;
        _dependencyController.text = plan.dependency;
        _effectsController.text = plan.effects;
        _goalController.text = plan.goal;
        _triggersController.text = plan.triggers;
        _alternativesController.text = plan.alternatives;
        _customPlanController.text = plan.customPlan;
      });
    }
  }

  Future<void> _savePlan() async {
    if (_dependencyController.text.trim().isEmpty ||
        _effectsController.text.trim().isEmpty ||
        _goalController.text.trim().isEmpty ||
        _triggersController.text.trim().isEmpty ||
        _alternativesController.text.trim().isEmpty ||
        _customPlanController.text.trim().isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Lütfen tüm alanları doldurun.')));
      return;
    }

    final plan = PlanModel(
      dependency: _dependencyController.text.trim(),
      effects: _effectsController.text.trim(),
      goal: _goalController.text.trim(),
      triggers: _triggersController.text.trim(),
      alternatives: _alternativesController.text.trim(),
      customPlan: _customPlanController.text.trim(),
      isCompleted: false,
    );

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_plan', jsonEncode(plan.toMap()));

    setState(() {
      _loadedPlan = plan;
    });
  }

  Future<void> _deletePlan() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('user_plan');
    setState(() {
      _loadedPlan = null;
      _dependencyController.clear();
      _effectsController.clear();
      _goalController.clear();
      _triggersController.clear();
      _alternativesController.clear();
      _customPlanController.clear();
    });
  }

  Future<void> _toggleCompletion() async {
    if (_loadedPlan == null) return;

    final updatedPlan = PlanModel(
      dependency: _loadedPlan!.dependency,
      effects: _loadedPlan!.effects,
      goal: _loadedPlan!.goal,
      triggers: _loadedPlan!.triggers,
      alternatives: _loadedPlan!.alternatives,
      customPlan: _loadedPlan!.customPlan,
      isCompleted: !_loadedPlan!.isCompleted,
    );

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_plan', jsonEncode(updatedPlan.toMap()));
    setState(() {
      _loadedPlan = updatedPlan;
    });
  }

  Widget _buildSection(String title, String content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        SizedBox(height: 4),
        Text(content, style: TextStyle(fontSize: 15)),
        SizedBox(height: 12),
      ],
    );
  }

  Widget _buildInputSection(
    String title,
    TextEditingController controller,
    String hint,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        SizedBox(height: 6),
        TextField(
          controller: controller,
          maxLines: null,
          decoration: InputDecoration(
            hintText: hint,
            border: OutlineInputBorder(),
          ),
        ),
        SizedBox(height: 20),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasPlan = _loadedPlan != null;

    return Scaffold(
      appBar: AppBar(
        title: Text('Bağımlılık Mücadelesi - Diğer'),
        leading: BackButton(onPressed: () => Navigator.pop(context)),
        actions: [
          if (hasPlan)
            IconButton(
              icon: Icon(Icons.delete),
              tooltip: 'Planı Sil',
              onPressed: _deletePlan,
            ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: hasPlan
            ? ListView(
                children: [
                  _buildSection('Bağımlılık:', _loadedPlan!.dependency),
                  _buildSection('Etkileri:', _loadedPlan!.effects),
                  _buildSection('Hedef:', _loadedPlan!.goal),
                  _buildSection('Tetikleyiciler:', _loadedPlan!.triggers),
                  _buildSection(
                    'Alternatif Davranışlar:',
                    _loadedPlan!.alternatives,
                  ),
                  _buildSection('Kendi Planın:', _loadedPlan!.customPlan),
                  SizedBox(height: 20),
                  ElevatedButton.icon(
                    icon: Icon(
                      _loadedPlan!.isCompleted
                          ? Icons.check_circle
                          : Icons.radio_button_unchecked,
                    ),
                    label: Text(
                      _loadedPlan!.isCompleted ? 'Tamamlandı' : 'Devam Ediyor',
                    ),
                    onPressed: _toggleCompletion,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _loadedPlan!.isCompleted
                          ? Colors.green
                          : Colors.orange,
                    ),
                  ),
                ],
              )
            : ListView(
                children: [
                  _buildInputSection(
                    'Bağımlılık Adı:',
                    _dependencyController,
                    'Örn: Oyun...',
                  ),
                  Text(
                    'Yolculuğuna Bilimsel Bir Bakış:',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  SizedBox(height: 6),
                  Text(generalInfo, style: TextStyle(fontSize: 15)),
                  SizedBox(height: 20),
                  _buildInputSection(
                    'Hayatında neleri etkiliyor?',
                    _effectsController,
                    'Örn: sağlık, ilişkiler...',
                  ),
                  _buildInputSection(
                    'Hedefin nedir?',
                    _goalController,
                    'Örn: tamamen bırakmak...',
                  ),
                  _buildInputSection(
                    'Tetikleyicilerin neler?',
                    _triggersController,
                    'Örn: stres, yalnızlık...',
                  ),
                  _buildInputSection(
                    'Alternatif davranışların?',
                    _alternativesController,
                    'Örn: yürüyüş, müzik...',
                  ),
                  _buildInputSection(
                    'Kendi özel planın:',
                    _customPlanController,
                    'Buraya stratejilerini yaz...',
                  ),
                  ElevatedButton.icon(
                    icon: Icon(Icons.save),
                    label: Text('Planı Kaydet'),
                    onPressed: _savePlan,
                  ),
                ],
              ),
      ),
    );
  }
}
