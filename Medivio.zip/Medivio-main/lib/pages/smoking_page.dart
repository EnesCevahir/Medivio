import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '/localization/localization.dart';

// NOT: Text widget'ları Localization (loc) sistemi ile güncellenmiştir.
// Bu kodun çalışması için build metodunun başında "final loc = Localization(language);" tanımı yapılmalıdır.

class SmokingPage extends StatelessWidget {
  final String language;
  const SmokingPage({Key? key, required this.language}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final loc = Localization(language);
    return Scaffold(
      appBar: AppBar(
        title: Text(loc.smokingAddiction),
        leading: BackButton(onPressed: () => Navigator.pop(context)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              loc.smokingQuestion,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ColdTurkeyPage()),
                );
              },
              child: Text(loc.coldTurkey),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const GradualReductionPage(),
                  ),
                );
              },
              child: Text(loc.gradualReduction),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
            const SizedBox(height: 40),
            Text(
              '${loc.selectedLanguage}$language',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}

class TriggerEntry {
  final DateTime time;
  final String place;
  final String situation;

  TriggerEntry({
    required this.time,
    required this.place,
    required this.situation,
  });
}

class ColdTurkeyPage extends StatefulWidget {
  const ColdTurkeyPage({Key? key}) : super(key: key);

  @override
  State<ColdTurkeyPage> createState() => _ColdTurkeyPageState();
}

class _ColdTurkeyPageState extends State<ColdTurkeyPage> {
  DateTime? _selectedDate;
  final List<TriggerEntry> _triggers = [];
  final Set<DateTime> _abstinentDays = {};

  final TextEditingController _placeController = TextEditingController();
  final TextEditingController _situationController = TextEditingController();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime today = DateTime.now();
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: today,
      firstDate: today,
      lastDate: DateTime(today.year + 1),
    );

    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _selectAbstinentDay(BuildContext context) async {
    final DateTime today = DateTime.now();
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: today,
      firstDate: DateTime(2020),
      lastDate: DateTime(today.year + 1),
    );

    if (picked != null) {
      final onlyDate = DateTime(picked.year, picked.month, picked.day);
      setState(() {
        if (_abstinentDays.contains(onlyDate)) {
          _abstinentDays.remove(onlyDate);
        } else {
          _abstinentDays.add(onlyDate);
        }
      });
    }
  }

  int calculateLongestStreak(Set<DateTime> abstinentDays) {
    if (abstinentDays.isEmpty) return 0;

    List<DateTime> sortedDays = abstinentDays.toList()
      ..sort((a, b) => a.compareTo(b));

    int longestStreak = 1;
    int currentStreak = 1;

    for (int i = 1; i < sortedDays.length; i++) {
      final prev = sortedDays[i - 1];
      final curr = sortedDays[i];

      if (curr.difference(prev).inDays == 1) {
        currentStreak++;
      } else {
        if (currentStreak > longestStreak) {
          longestStreak = currentStreak;
        }
        currentStreak = 1;
      }
    }
    if (currentStreak > longestStreak) {
      longestStreak = currentStreak;
    }

    return longestStreak;
  }

  String getScientificReward(int streak) {
    if (streak >= 60) return '🏅 (Özel Kupa)';
    if (streak >= 30) return '🏆 (Kupa)';
    if (streak >= 14) return '🥇 (Altın Madalya)';
    if (streak >= 7) return '🥈 (Gümüş Madalya)';
    if (streak >= 3) return '🥉 (Bronz Madalya)';
    return '😞 Henüz ödül yok';
  }

  void _showAddTriggerDialog() {
    _placeController.clear();
    _situationController.clear();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sigara içmek istediğin anı kaydet'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: _placeController,
                decoration: const InputDecoration(
                  labelText: 'Yer (örneğin: Ev, İş, Kafe)',
                ),
              ),
              TextField(
                controller: _situationController,
                decoration: const InputDecoration(
                  labelText: 'Durum (örneğin: Stresli, Arkadaşlarla)',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('İptal'),
          ),
          ElevatedButton(
            onPressed: () {
              final place = _placeController.text.trim();
              final situation = _situationController.text.trim();

              if (place.isEmpty || situation.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Lütfen tüm alanları doldurun.'),
                  ),
                );
                return;
              }

              setState(() {
                _triggers.add(
                  TriggerEntry(
                    time: DateTime.now(),
                    place: place,
                    situation: situation,
                  ),
                );
              });

              Navigator.pop(context);
            },
            child: const Text('Kaydet'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _placeController.dispose();
    _situationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final formattedDate = _selectedDate != null
        ? DateFormat('dd MMMM yyyy', 'tr_TR').format(_selectedDate!)
        : 'Henüz seçilmedi';

    final longestStreak = calculateLongestStreak(_abstinentDays);
    final reward = getScientificReward(longestStreak);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Aniden Bırakma'),
        leading: BackButton(onPressed: () => Navigator.pop(context)),
        actions: [
          IconButton(
            icon: const Icon(Icons.lightbulb),
            tooltip: 'Motivasyon',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const MotivationPage()),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const MotivationPage()),
                  );
                },
                icon: const Icon(Icons.lightbulb),
                label: const Text('Motivasyona mı ihtiyacın var?'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orangeAccent,
                  padding: const EdgeInsets.symmetric(
                    vertical: 16,
                    horizontal: 24,
                  ),
                  textStyle: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 30),

              const Text(
                'Harika! Aniden bırakmayı seçtin.\n\nBırakmak istediğin tarihi belirleyerek bu önemli adımı planlamaya başla.',
                style: TextStyle(fontSize: 18),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () => _selectDate(context),
                child: const Text('Bırakma Günü Seç'),
              ),
              const SizedBox(height: 10),
              Text(
                'Seçilen Tarih: $formattedDate',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const Divider(height: 40, thickness: 2),
              const Text(
                'İçmediğin günleri işaretle:',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              ElevatedButton.icon(
                onPressed: () => _selectAbstinentDay(context),
                icon: const Icon(Icons.event_available),
                label: const Text('İçmediğim Gün Seç'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    vertical: 14,
                    horizontal: 20,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: _abstinentDays.map((day) {
                  return Chip(
                    label: Text(DateFormat('dd.MM.yyyy').format(day)),
                    onDeleted: () {
                      setState(() {
                        _abstinentDays.remove(day);
                      });
                    },
                  );
                }).toList(),
              ),
              const Divider(height: 40, thickness: 2),
              Text(
                'En Uzun Kesintisiz İçilmeyen Gün Sayısı: $longestStreak',
                style: const TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 6),
              Text('Ödülün: $reward', style: const TextStyle(fontSize: 24)),
              const SizedBox(height: 8),
              const Text(
                'Ödüller, içilmeyen gün sayına göre verilir:\n'
                '3 gün - Bronz Madalya 🥉\n'
                '7 gün - Gümüş Madalya 🥈\n'
                '14 gün - Altın Madalya 🥇\n'
                '30 gün - Kupa 🏆\n'
                '60+ gün - Özel Kupa 🏅',
                style: TextStyle(fontSize: 14, color: Colors.grey),
                textAlign: TextAlign.center,
              ),
              const Divider(height: 40, thickness: 2),
              const Text(
                'Sigara içmek istediğin anları kaydet ve farkındalığını artır:',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              ElevatedButton.icon(
                onPressed: _showAddTriggerDialog,
                icon: const Icon(Icons.add),
                label: const Text('Şu An Sigara İçmek İstedim'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    vertical: 14,
                    horizontal: 20,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              if (_triggers.isEmpty)
                const Text(
                  'Henüz sigara içme anlarını kaydetmedin.',
                  style: TextStyle(fontSize: 14, fontStyle: FontStyle.italic),
                ),
              for (var trigger in _triggers)
                Card(
                  margin: const EdgeInsets.symmetric(vertical: 6),
                  child: ListTile(
                    title: Text(
                      '${DateFormat('dd.MM.yyyy HH:mm').format(trigger.time)}',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      'Yer: ${trigger.place}\nDurum: ${trigger.situation}',
                    ),
                    isThreeLine: true,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// Burada MotivationPage tanımlı olmalı, yoksa kendi sayfanı ekle.

class GradualReductionPage extends StatefulWidget {
  const GradualReductionPage({Key? key}) : super(key: key);

  @override
  State<GradualReductionPage> createState() => _GradualReductionPageState();
}

class _GradualReductionPageState extends State<GradualReductionPage> {
  DateTime? _selectedDate;
  int _initialCigarettes = 10;
  int _targetCigarettes = 0;
  int _dailyGoal = 1;

  final TextEditingController _initialController = TextEditingController();
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _dailyGoalController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _initialController.text = '10';
    _targetController.text = '0';
    _dailyGoalController.text = '1';
    _loadPlanFromPrefs();
  }

  @override
  void dispose() {
    _initialController.dispose();
    _targetController.dispose();
    _dailyGoalController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime today = DateTime.now();
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: today,
      firstDate: today,
      lastDate: DateTime(today.year + 1),
    );

    if (picked != null) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  String getDateString() {
    if (_selectedDate == null) return 'Henüz seçilmedi';
    return DateFormat('dd MMMM yyyy', 'tr_TR').format(_selectedDate!);
  }

  void _updateValues() {
    final initial = int.tryParse(_initialController.text) ?? 10;
    final target = int.tryParse(_targetController.text) ?? 0;
    final dailyGoal = int.tryParse(_dailyGoalController.text) ?? 1;

    int fixedTarget = target <= initial ? target : initial;
    int fixedDailyGoal = dailyGoal < 1 ? 1 : dailyGoal;

    setState(() {
      _initialCigarettes = initial;
      _targetCigarettes = fixedTarget;
      _dailyGoal = fixedDailyGoal;

      // Controller değerlerini de güncelle (kullanıcı yanlış girerse düzeltsin)
      _targetController.text = '$_targetCigarettes';
      _dailyGoalController.text = '$_dailyGoal';
    });
  }

  // SharedPreferences'tan planı yükle
  Future<void> _loadPlanFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();

    final selectedDateMillis = prefs.getInt('selectedDate');
    if (selectedDateMillis != null) {
      setState(() {
        _selectedDate = DateTime.fromMillisecondsSinceEpoch(selectedDateMillis);
      });
    }

    setState(() {
      _initialCigarettes = prefs.getInt('initialCigarettes') ?? 10;
      _targetCigarettes = prefs.getInt('targetCigarettes') ?? 0;
      _dailyGoal = prefs.getInt('dailyGoal') ?? 1;

      _initialController.text = '$_initialCigarettes';
      _targetController.text = '$_targetCigarettes';
      _dailyGoalController.text = '$_dailyGoal';
    });
  }

  // SharedPreferences'a planı kaydet
  Future<void> _savePlanToPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    if (_selectedDate != null) {
      await prefs.setInt('selectedDate', _selectedDate!.millisecondsSinceEpoch);
    }
    await prefs.setInt('initialCigarettes', _initialCigarettes);
    await prefs.setInt('targetCigarettes', _targetCigarettes);
    await prefs.setInt('dailyGoal', _dailyGoal);
  }

  // SharedPreferences'tan planı sil
  Future<void> _clearPlanFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('selectedDate');
    await prefs.remove('initialCigarettes');
    await prefs.remove('targetCigarettes');
    await prefs.remove('dailyGoal');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Aşamalı Azaltma'),
        leading: BackButton(onPressed: () => Navigator.pop(context)),
        actions: [
          IconButton(
            icon: const Icon(Icons.lightbulb),
            tooltip: 'Motivasyon',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const MotivationPage()),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const MotivationPage()),
                  );
                },
                icon: const Icon(Icons.lightbulb),
                label: const Text('Motivasyona mı ihtiyacın var?'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orangeAccent,
                  padding: const EdgeInsets.symmetric(
                    vertical: 16,
                    horizontal: 24,
                  ),
                  textStyle: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 30),

              const Text(
                'Aşamalı azaltma yöntemi ile sigara sayını yavaş yavaş düşürerek bırakmaya hazırlanabilirsin.',
                style: TextStyle(fontSize: 18),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () => _selectDate(context),
                child: const Text('Azaltmaya Başlama Tarihini Seç'),
              ),
              const SizedBox(height: 10),
              Text(
                'Seçilen Tarih: ${getDateString()}',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const Divider(height: 40, thickness: 2),
              TextField(
                controller: _initialController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Günlük Başlangıç Sigara Sayısı',
                  border: OutlineInputBorder(),
                ),
                onEditingComplete: _updateValues,
              ),
              const SizedBox(height: 20),
              TextField(
                controller: _targetController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Hedef Günlük Sigara Sayısı',
                  border: OutlineInputBorder(),
                ),
                onEditingComplete: _updateValues,
              ),
              const SizedBox(height: 20),
              TextField(
                controller: _dailyGoalController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Günde Kaç Sigara Azaltılacak?',
                  border: OutlineInputBorder(),
                ),
                onEditingComplete: _updateValues,
              ),
              const SizedBox(height: 30),
              Text(
                'Plan: $_initialCigarettes → $_targetCigarettes sigaraya\nGünde $_dailyGoal sigara azaltılacak.',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () async {
                  if (_selectedDate == null) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Lütfen bir tarih seçin.')),
                    );
                    return;
                  }
                  if (_initialCigarettes < _targetCigarettes) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Başlangıç sayısı hedef sayıdan büyük olmalı.',
                        ),
                      ),
                    );
                    return;
                  }

                  // Güncel değerleri al, uygunsa kaydet
                  setState(() {
                    _initialCigarettes =
                        int.tryParse(_initialController.text) ?? 10;
                    _targetCigarettes =
                        int.tryParse(_targetController.text) ?? 0;
                    _dailyGoal = int.tryParse(_dailyGoalController.text) ?? 1;

                    if (_targetCigarettes > _initialCigarettes) {
                      _targetCigarettes = _initialCigarettes;
                    }
                    if (_dailyGoal < 1) {
                      _dailyGoal = 1;
                    }

                    _targetController.text = '$_targetCigarettes';
                    _dailyGoalController.text = '$_dailyGoal';
                  });

                  await _savePlanToPrefs();

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Plan başarıyla kaydedildi!')),
                  );
                },
                child: const Text('Planı Kaydet'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    vertical: 16,
                    horizontal: 30,
                  ),
                ),
              ),

              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: () async {
                  await _clearPlanFromPrefs();

                  setState(() {
                    _selectedDate = null;
                    _initialCigarettes = 10;
                    _targetCigarettes = 0;
                    _dailyGoal = 1;

                    _initialController.text = '10';
                    _targetController.text = '0';
                    _dailyGoalController.text = '1';
                  });

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Mevcut plan silindi. Yeni plan oluşturabilirsiniz.',
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.delete),
                label: const Text('Planı Sil'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  padding: const EdgeInsets.symmetric(
                    vertical: 16,
                    horizontal: 24,
                  ),
                  textStyle: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const ReductionPlanDisplayPage(),
                    ),
                  );
                },
                icon: const Icon(Icons.visibility),
                label: const Text('Planı Göster'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueGrey,
                  padding: const EdgeInsets.symmetric(
                    vertical: 16,
                    horizontal: 24,
                  ),
                  textStyle: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ReductionPlanDisplayPage extends StatefulWidget {
  const ReductionPlanDisplayPage({Key? key}) : super(key: key);

  @override
  State<ReductionPlanDisplayPage> createState() =>
      _ReductionPlanDisplayPageState();
}

class _ReductionPlanDisplayPageState extends State<ReductionPlanDisplayPage> {
  DateTime? _selectedDate;
  int? _initialCigarettes;
  int? _targetCigarettes;
  int? _dailyGoal;

  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadPlan();
  }

  Future<void> _loadPlan() async {
    final prefs = await SharedPreferences.getInstance();

    final int? dateMillis = prefs.getInt('selectedDate');
    final int? initial = prefs.getInt('initialCigarettes');
    final int? target = prefs.getInt('targetCigarettes');
    final int? dailyGoal = prefs.getInt('dailyGoal');

    setState(() {
      _selectedDate = dateMillis != null
          ? DateTime.fromMillisecondsSinceEpoch(dateMillis)
          : null;
      _initialCigarettes = initial;
      _targetCigarettes = target;
      _dailyGoal = dailyGoal;
      _isLoading = false;
    });
  }

  String _formatDate(DateTime? date) {
    if (date == null) return 'Henüz seçilmedi';
    return DateFormat('dd MMMM yyyy', 'tr_TR').format(date);
  }

  // Bugün içmen gereken sigara sayısını hesaplayan fonksiyon
  int _calculateTodayCigarettes() {
    if (_selectedDate == null ||
        _initialCigarettes == null ||
        _targetCigarettes == null ||
        _dailyGoal == null) {
      return 0;
    }

    final daysPassed = DateTime.now().difference(_selectedDate!).inDays;
    final reducedAmount = daysPassed * _dailyGoal!;
    int cigarettesToday = _initialCigarettes! - reducedAmount;
    if (cigarettesToday < _targetCigarettes!) {
      cigarettesToday = _targetCigarettes!;
    }
    return cigarettesToday;
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(title: Text('Plan Detayı')),
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (_selectedDate == null ||
        _initialCigarettes == null ||
        _targetCigarettes == null ||
        _dailyGoal == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Plan Detayı')),
        body: const Center(child: Text('Kayıtlı bir plan bulunamadı.')),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Plan Detayı')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Başlama Tarihi:',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            Text(
              _formatDate(_selectedDate),
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),

            Text(
              'Başlangıç Sigara Sayısı:',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            Text(
              '$_initialCigarettes',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),

            Text(
              'Hedef Sigara Sayısı:',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            Text(
              '$_targetCigarettes',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),

            Text(
              'Günlük Azaltma Miktarı:',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            Text(
              '$_dailyGoal',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 20),

            // Burada yeni eklenen kısım:
            Text(
              'Bugün En fazla İçebileceğin Sigara Sayısı:',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            Text(
              '${_calculateTodayCigarettes()}',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.redAccent,
              ),
            ),

            const SizedBox(height: 40),
            Center(
              child: ElevatedButton.icon(
                icon: const Icon(Icons.edit),
                label: const Text('Planı Düzenle'),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class MotivationPage extends StatelessWidget {
  const MotivationPage({Key? key}) : super(key: key);

  final String motivationText = '''
Sigara bırakmak zor ama imkansız değil! 💪

Bugün attığın her adım, daha sağlıklı ve özgür bir geleceğe doğru atılmış büyük bir adımdır. Unutma, değişim küçük adımlarla başlar ama etkisi büyük olur. Zorluklar karşına çıktığında, gücünü hatırla ve pes etme!

Sen bu mücadeleyi kazanabilecek güçtesin!

Hadi, kendine inan ve her gününü bir zafer olarak kutla! 🚀
''';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Motivasyon'),
        leading: BackButton(onPressed: () => Navigator.pop(context)),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: SelectableText(
            motivationText,
            style: const TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              color: Colors.deepPurple,
              height: 1.4,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
