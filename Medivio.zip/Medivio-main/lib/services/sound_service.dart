import 'package:audioplayers/audioplayers.dart';

final AudioPlayer _player = AudioPlayer();

Future<void> playAlarmSound() async {
  await _player.play(AssetSource('alarm.mp3'));
}
