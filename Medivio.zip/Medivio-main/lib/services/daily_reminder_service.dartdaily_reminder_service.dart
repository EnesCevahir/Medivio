import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz;

class DailyReminderService {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();

  static Future<void> scheduleDailyReminder(String language) async {
    final loc = Localization(language);
    tz.initializeTimeZones();

    await _notificationsPlugin.zonedSchedule(
      999, // unique id
      loc.dailyReminderTitle,
      loc.dailyReminderBody,
      _nextInstanceOfNineAM(),
      NotificationDetails(
        android: AndroidNotificationDetails(
          'daily_reminder_channel',
          loc.dailyReminderChannelName,
          channelDescription: loc.dailyReminderChannelDescription,
          importance: Importance.max,
          priority: Priority.high,
          playSound: true,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  static tz.TZDateTime _nextInstanceOfNineAM() {
    final now = tz.TZDateTime.now(tz.local);
    final nineAM = tz.TZDateTime(tz.local, now.year, now.month, now.day, 9);

    return now.isAfter(nineAM) ? nineAM.add(const Duration(days: 1)) : nineAM;
  }
}

class Localization {
  final String language;
  Localization(this.language);

  String get dailyReminderTitle =>
      language == 'tr' ? '🧠 Günlük Hatırlatma' : '🧠 Daily Reminder';

  String get dailyReminderBody => language == 'tr'
      ? 'Bugün kendin için bir adım attın mı? Planını gözden geçir!'
      : 'Did you take a step for yourself today? Review your plan!';

  String get dailyReminderChannelName =>
      language == 'tr' ? 'Günlük Hatırlatmalar' : 'Daily Reminders';

  String get dailyReminderChannelDescription => language == 'tr'
      ? 'Her gün saat 09:00’da kullanıcıyı hatırlatır'
      : 'Reminds user every day at 9:00 AM';
}
