import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:audioplayers/audioplayers.dart';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();
final AudioPlayer _player = AudioPlayer();

final androidDetails = AndroidNotificationDetails(
  'daily_alarm_channel',
  'Günlük Alarm',
  channelDescription: 'Her gün aynı saatte alarm',
  importance: Importance.max,
  priority: Priority.high,
  playSound: true,
  sound: RawResourceAndroidNotificationSound('alarm'),
);

final NotificationDetails platformDetails = NotificationDetails(
  android: androidDetails,
);

Future<void> playAlarmSound() async {
  await _player.play(AssetSource('sounds/alarm.mp3'));
}
