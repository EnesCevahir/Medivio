import 'dart:convert';
import 'package:flutter/services.dart';

Future<Map<String, List<String>>> loadDepressionTips() async {
  final jsonString = await rootBundle.loadString(
    'assets/data/depression_tips.json',
  );
  final Map<String, dynamic> jsonMap = jsonDecode(jsonString);
  return jsonMap.map((key, value) => MapEntry(key, List<String>.from(value)));
}
