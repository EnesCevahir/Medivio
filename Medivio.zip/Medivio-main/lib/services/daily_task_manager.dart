import 'package:shared_preferences/shared_preferences.dart';
import '../localization/localization.dart';

class DailyTaskManager {
  static const String _lastTaskDateKey = 'last_task_date';
  static const String _lastTaskIndexKey = 'last_task_index';
  static const String _taskCompletedTimeKey = 'task_completed_time';

  static List<String> getDailyTasks(Localization loc) {
    return [
      loc.dailyTask1,
      loc.dailyTask2,
      loc.dailyTask3,
      loc.dailyTask4,
      loc.dailyTask5,
      loc.dailyTask6,
      loc.dailyTask7,
      loc.dailyTask8,
      loc.dailyTask9,
      loc.dailyTask10,
      loc.dailyTask11,
      loc.dailyTask12,
      loc.dailyTask13,
      loc.dailyTask14,
      loc.dailyTask15,
    ];
  }

  /// Günün görevini getirir
  static Future<String> getTodayTask(Localization loc) async {
    final prefs = await SharedPreferences.getInstance();
    final now = DateTime.now();
    final todayStr = '${now.year}-${now.month}-${now.day}';

    String? lastDate = prefs.getString(_lastTaskDateKey);
    int? lastIndex = prefs.getInt(_lastTaskIndexKey);

    final tasks = getDailyTasks(loc);

    if (lastDate == todayStr && lastIndex != null) {
      return tasks[lastIndex];
    } else {
      int newIndex = lastIndex == null ? 0 : (lastIndex + 1) % tasks.length;
      await prefs.setString(_lastTaskDateKey, todayStr);
      await prefs.setInt(_lastTaskIndexKey, newIndex);
      return tasks[newIndex];
    }
  }

  /// Görevi tamamlandı olarak işaretler (timestamp kaydeder)
  static Future<void> markTaskAsCompleted() async {
    final prefs = await SharedPreferences.getInstance();
    final now = DateTime.now();
    await prefs.setInt(_taskCompletedTimeKey, now.millisecondsSinceEpoch);
    print("🟢 Görev tamamlandı olarak işaretlendi: ${now.toIso8601String()}");
  }

  /// Görev 07:00 bazlı bugünkü zaman diliminde tamamlandı mı?
  static Future<bool> isTaskCompletedToday() async {
    final prefs = await SharedPreferences.getInstance();
    final millis = prefs.getInt(_taskCompletedTimeKey);
    if (millis == null) {
      print("🔴 Görev daha önce hiç tamamlanmamış.");
      return false;
    }

    final completedTime = DateTime.fromMillisecondsSinceEpoch(millis);
    final now = DateTime.now();

    final todayReset = DateTime(now.year, now.month, now.day, 7);
    final yesterday = now.subtract(const Duration(days: 1));
    final yesterdayReset = DateTime(
      yesterday.year,
      yesterday.month,
      yesterday.day,
      7,
    );
    final resetBase = now.isBefore(todayReset) ? yesterdayReset : todayReset;

    print("⏱ Şu an: $now");
    print("✅ Tamamlanma zamanı: $completedTime");
    print("🔄 Reset sınırı: $resetBase");

    final result = completedTime.isAfter(resetBase);
    print("🧩 Bugünün görevi tamamlandı mı? $result");

    return result;
  }
}
