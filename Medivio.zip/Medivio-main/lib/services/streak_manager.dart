import 'package:shared_preferences/shared_preferences.dart';

class StreakManager {
  static const String _lastLoginTimeKey = 'last_login_time';
  static const String _streakCountKey = 'streak_count';

  static Future<int> updateStreak() async {
    final prefs = await SharedPreferences.getInstance();
    final now = DateTime.now();

    // Bugünün 07:00 zamanı
    final todayReset = DateTime(now.year, now.month, now.day, 7);

    // Eğer şu an 07:00'dan önceyse, reset zamanı dünün 07:00'ı olur
    final resetBase = now.isBefore(todayReset)
        ? todayReset.subtract(const Duration(days: 1))
        : todayReset;

    final lastLoginMillis = prefs.getInt(_lastLoginTimeKey);
    int streak = prefs.getInt(_streakCountKey) ?? 0;

    if (lastLoginMillis != null) {
      final lastLoginTime = DateTime.fromMillisecondsSinceEpoch(
        lastLoginMillis,
      );

      // Eğer son login resetBase'den sonra ise, bugün zaten giriş yapılmış, streak artmaz
      if (lastLoginTime.isAfter(resetBase)) {
        return streak;
      }
    }

    // Günlük streak güncelleme zamanı geldi

    // Son login zamanı sıfırlama zamanından önce ise,
    // farkı gün olarak hesapla
    final lastLoginTime = lastLoginMillis != null
        ? DateTime.fromMillisecondsSinceEpoch(lastLoginMillis)
        : null;

    int dayDifference = 0;
    if (lastLoginTime != null) {
      // resetBase'a göre gün farkı
      dayDifference = resetBase.difference(lastLoginTime).inDays;
    }

    if (dayDifference == 1) {
      // Ardışık gün girişinde streak artar
      streak += 1;
    } else {
      // Günler arasında boşluk varsa streak sıfırlanır
      streak = 1;
    }

    // Güncellemeleri kaydet
    await prefs.setInt(_streakCountKey, streak);
    await prefs.setInt(_lastLoginTimeKey, now.millisecondsSinceEpoch);

    return streak;
  }
}
