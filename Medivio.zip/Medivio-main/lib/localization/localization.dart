class Localization {
  final String language;

  Localization(this.language);
  String get cancel => language == 'tr' ? 'İptal' : 'Cancel';

  String get addictionsTitle =>
      language == 'tr' ? 'Bağımlılıklar' : 'Addictions';

  String get vitaminsTitle => language == 'tr' ? 'Vitaminler' : 'Vitamins';

  String get vitaminsIntro => language == 'tr'
      ? 'Vitaminler vücut sağlığı için hayati önem taşır. Aşağıda bazı temel vitaminler hakkında bilgiler bulabilirsiniz.'
      : 'Vitamins are essential for maintaining body health. Below are some basic vitamin facts.';

  String get vitaminDInfo => language == 'tr'
      ? 'Vitamin D, kemik sağlığı, bağışıklık sistemi fonksiyonları ve kas fonksiyonları için kritik önemdedir. Eksikliği kemik erimesi, kas güçsüzlüğü ve bağışıklık zayıflığına yol açabilir. Güneş ışığı, somon, uskumru, yumurta sarısı ve güçlendirilmiş süt ürünleri gibi besinlerle alınabilir. Dünya genelinde en sık eksikliği görülen vitamindir. Sebebi yetersiz güneşlenmektir.'
      : 'Vitamin D is critical for bone health, immune system function, and muscle function. Deficiency can lead to osteoporosis, muscle weakness, and weakened immunity. It can be obtained through sunlight exposure, salmon, mackerel, egg yolks, and fortified dairy products.It is the most common vitamin deficiency worldwide. The cause is inadequate sun exposure.';

  String get vitaminB12Info => language == 'tr'
      ? 'Vitamin B12, sinir sistemi sağlığı, DNA sentezi ve kırmızı kan hücrelerinin üretimi için gereklidir. Eksikliği anemi ve nörolojik sorunlara yol açabilir. Genellikle et, balık, süt ürünleri ve yumurta gibi hayvansal kaynaklardan alınır. Vejetaryenler ve yaşlılar takviye kullanabilir.'
      : 'Vitamin B12 is essential for nervous system health, DNA synthesis, and red blood cell production. Deficiency can cause anemia and neurological issues. It is typically found in animal products such as meat, fish, dairy, and eggs. Vegetarians and elderly may need supplements.';

  String get vitaminCInfo => language == 'tr'
      ? 'Vitamin C, bağışıklık sistemini destekler, antioksidan özellik taşır, cilt sağlığını korur ve demir emilimini artırır. Eksikliği skorbüt hastalığına yol açabilir. Portakal, çilek, kivi, brokoli ve kırmızı biber gibi taze sebze ve meyvelerden kolayca alınabilir.'
      : 'Vitamin C supports the immune system, acts as an antioxidant, protects skin health, and enhances iron absorption. Deficiency can cause scurvy. It is easily obtained from fresh fruits and vegetables like oranges, strawberries, kiwi, broccoli, and red peppers.';

  String get vitaminAInfo => language == 'tr'
      ? 'Vitamin A, göz sağlığı, bağışıklık fonksiyonları ve hücre büyümesi için gereklidir. Eksikliği gece körlüğü ve bağışıklık zayıflığına neden olabilir. Havuç, tatlı patates, ıspanak ve karaciğer gibi besinlerde bulunur.'
      : 'Vitamin A is necessary for eye health, immune function, and cell growth. Deficiency can cause night blindness and weakened immunity. It is found in carrots, sweet potatoes, spinach, and liver.';

  String get vitaminEInfo => language == 'tr'
      ? 'Vitamin E, güçlü bir antioksidandır ve hücre zarlarını serbest radikallerin zararından korur. Eksikliği nadirdir ama sinir ve kas sorunlarına yol açabilir. Bitkisel yağlar, fındık, tohum ve yeşil yapraklı sebzelerde bulunur.'
      : 'Vitamin E is a powerful antioxidant that protects cell membranes from free radical damage. Deficiency is rare but can lead to nerve and muscle problems. It is found in vegetable oils, nuts, seeds, and green leafy vegetables.';

  String get vitaminKInfo => language == 'tr'
      ? 'Vitamin K, kan pıhtılaşması için gereklidir ve kemik metabolizmasına katkıda bulunur. Eksikliği kanama riskini artırır. Yeşil yapraklı sebzeler, brokoli ve lahana iyi kaynaklardır.'
      : 'Vitamin K is essential for blood clotting and contributes to bone metabolism. Deficiency increases bleeding risk. It is abundant in green leafy vegetables, broccoli, and cabbage.';

  String get folateInfo => language == 'tr'
      ? 'Folik asit (B9 vitamini), DNA sentezi ve hücre bölünmesi için gereklidir. Gebelikte eksikliği nöral tüp defektlerine yol açabilir. Yeşil yapraklı sebzeler, baklagiller ve güçlendirilmiş tahıllardan alınabilir.'
      : 'Folic acid (Vitamin B9) is necessary for DNA synthesis and cell division. Deficiency during pregnancy can cause neural tube defects. It can be obtained from green leafy vegetables, legumes, and fortified grains.';

  String get biotinInfo => language == 'tr'
      ? 'Biotin (B7 vitamini), cilt, saç ve metabolizma sağlığı için önemlidir. Genellikle eksikliği nadirdir. Yumurta, badem ve yulaf iyi kaynaklardır.'
      : 'Biotin (Vitamin B7) is important for skin, hair, and metabolic health. Deficiency is rare. Eggs, almonds, and oats are good sources.';

  String get vitaminB6Info => language == 'tr'
      ? 'Vitamin B6, protein metabolizması, beyin gelişimi ve bağışıklık fonksiyonları için gereklidir. Et, balık, muz ve patates gibi besinlerde bulunur.'
      : 'Vitamin B6 is necessary for protein metabolism, brain development, and immune functions. It is found in meat, fish, bananas, and potatoes.';

  String get dailyTaskTitle =>
      language == 'tr' ? 'Günün Mini Görevi' : 'Daily Mini Task';
  String get loading => language == 'tr' ? 'Yükleniyor...' : 'Loading...';
  String get completeTask =>
      language == 'tr' ? 'Görevi Tamamla' : 'Complete Task';
  String get taskCompleted =>
      language == 'tr' ? 'Görev Tamamlandı' : 'Task Completed';

  String streakCongrats(int days) {
    if (language == 'tr') {
      return '$days gün üst üste giriş yaptın! Tebrikler 🎉';
    } else {
      return 'You logged in $days days in a row! Congrats 🎉';
    }
  }

  String streakCount(int days) {
    if (language == 'tr') {
      return 'Üst üste giriş: $days gün';
    } else {
      return 'Current streak: $days days';
    }
  }

  String get addictionSmoking => language == 'tr' ? 'Sigara' : 'Smoking';
  String get addictionAlcohol => language == 'tr' ? 'Alkol' : 'Alcohol';
  String get addictionSocialMedia =>
      language == 'tr' ? 'Telefon / Sosyal Medya' : 'Phone / Social Media';
  String get addictionGaming => language == 'tr' ? 'Oyun' : 'Gaming';
  String get addictionCaffeine => language == 'tr' ? 'Kafein' : 'Caffeine';
  String get addictionOther => language == 'tr' ? 'Diğer' : 'Other';

  String get stressAndAnxiety =>
      language == 'tr' ? 'Stres & Anksiyete' : 'Stress & Anxiety';
  String get sleepTitle => language == 'tr' ? 'Uyku' : 'Sleep';
  String get nutritionTitle => language == 'tr' ? 'Beslenme' : 'Nutrition';
  String get depressionTitleShort =>
      language == 'tr' ? 'Depresyon' : 'Depression';

  String get settingsTitle => language == 'tr' ? 'Ayarlar' : 'Settings';

  String get depressionTitle =>
      language == 'tr' ? 'Depresyon Desteği' : 'Depression Support';

  String get dailyReminderTitle =>
      language == 'tr' ? '🧠 Günlük Hatırlatma' : '🧠 Daily Reminder';

  String get dailyReminderBody => language == 'tr'
      ? 'Bugün kendin için bir adım attın mı? Planını gözden geçir!'
      : 'Did you take a step for yourself today? Review your plan!';

  String get dailyTask1 => language == 'tr'
      ? 'Bugün 15 dk doğada vakit geçir.'
      : 'Spend 15 mins in nature today.';
  String get dailyTask2 => language == 'tr'
      ? 'Bugün kendine iyi gelen birini ara.'
      : 'Call someone who makes you feel good today.';
  String get dailyTask3 => language == 'tr'
      ? 'Derin nefes al ve rahatla.'
      : 'Take a deep breath and relax.';
  String get dailyTask4 => language == 'tr'
      ? 'Yürüyüş yap veya hafif egzersiz yap.'
      : 'Go for a walk or do light exercise.';
  String get dailyTask5 => language == 'tr'
      ? 'Bir şeyler yaz, günlük tut.'
      : 'Write something, keep a journal.';
  String get dailyTask6 => language == 'tr'
      ? 'Bir arkadaşına teşekkür et.'
      : 'Thank a friend today.';
  String get dailyTask7 =>
      language == 'tr' ? '5 dakika meditasyon yap.' : 'Meditate for 5 minutes.';
  String get dailyTask8 => language == 'tr'
      ? 'Sevdiğin bir müziği dinle.'
      : 'Listen to your favorite music.';
  String get dailyTask9 =>
      language == 'tr' ? 'Pozitif bir şeyler oku.' : 'Read something positive.';
  String get dailyTask10 =>
      language == 'tr' ? 'Bir küçük iyilik yap.' : 'Do a small kindness.';
  String get dailyTask11 =>
      language == 'tr' ? 'Suyu yeterince iç.' : 'Drink enough water.';
  String get dailyTask12 => language == 'tr'
      ? 'Kendine güzel bir mola ver.'
      : 'Give yourself a nice break.';
  String get dailyTask13 => language == 'tr'
      ? 'Doğayla kısa bir yürüyüş yap.'
      : 'Take a short walk in nature.';
  String get dailyTask14 => language == 'tr'
      ? 'Gün içinde derin nefes al.'
      : 'Take deep breaths during the day.';
  String get dailyTask15 => language == 'tr'
      ? 'Sevdiğin bir anıyı hatırla.'
      : 'Recall a happy memory.';
  String? get permissionNeededTitle => language == 'tr'
      ? 'Bildirim İzni Gerekli'
      : 'Notification Permission Required';

  String? get permissionNeededMessage => language == 'tr'
      ? 'Bildirim gönderebilmemiz için izin vermeniz gerekiyor. Ayarlar sayfasına yönlendirileceksiniz.'
      : 'We need your permission to send notifications. You will be redirected to the settings page.';

  String? get goToSettings => language == 'tr' ? 'Ayarlar' : 'Settings';

  String get dailyReminderChannelName =>
      language == 'tr' ? 'Günlük Hatırlatmalar' : 'Daily Reminders';

  String get dailyReminderChannelDescription => language == 'tr'
      ? 'Her gün saat 09:00’da kullanıcıyı hatırlatır'
      : 'Reminds user every day at 9:00 AM';

  String get depressionInfoText => language == 'tr'
      ? 'Depresyon, kişinin duygu, düşünce ve davranışlarını etkileyen yaygın bir ruhsal sağlık sorunudur. '
            'Uzun süreli üzüntü, enerji kaybı, ilgi ve zevk alma yetisinde azalma gibi belirtilerle kendini gösterir. '
            'Depresyon, yaşam kalitesini düşürür ve günlük işleri yapmayı zorlaştırabilir.\n\n'
            'Bilimsel olarak önerilen başlıca mücadele yöntemleri şunlardır:\n'
            '- Psikolog veya psikiyatrist gibi uzmanlardan profesyonel destek alınması, terapi ve gerektiğinde ilaç tedavisi uygulanması.\n'
            '- Düzenli fiziksel egzersiz, vücuttaki mutluluk hormonu (endorfin) seviyesini artırır ve ruh halini iyileştirir.\n'
            '- Dengeli ve sağlıklı beslenme, beyin fonksiyonlarının desteklenmesinde önemlidir.\n'
            '- Sosyal ilişkilerin sürdürülmesi ve güvenilir kişilerle duyguların paylaşılması, iyileşmeye katkı sağlar.\n'
            '- Günlük rutinlerin oluşturulması, düzenli uyku ve aktivite programları depresyon semptomlarını azaltabilir.\n\n'
            'Unutmayın, depresyon tedavi edilebilir bir hastalıktır ve doğru yöntemlerle yaşam kaliteniz önemli ölçüde iyileşebilir.'
      : 'Depression is a common mental health disorder that affects a person\'s emotions, thoughts, and behaviors. '
            'It is characterized by prolonged feelings of sadness, loss of energy, and decreased interest or pleasure in activities. '
            'Depression reduces quality of life and can make everyday tasks difficult.\n\n'
            'Scientifically supported methods to cope with depression include:\n'
            '- Seeking professional help from psychologists or psychiatrists, including therapy and medication if necessary.\n'
            '- Regular physical exercise, which increases levels of endorphins (the body\'s natural mood lifters) and improves mental health.\n'
            '- Balanced and healthy nutrition, important for optimal brain function.\n'
            '- Maintaining social connections and sharing feelings with trusted individuals, which supports recovery.\n'
            '- Establishing daily routines, including regular sleep and activity schedules, can help reduce depressive symptoms.\n\n'
            'Remember, depression is a treatable condition, and with the right approach, your quality of life can improve significantly.';

  String get depressionDesc => language == 'tr'
      ? 'Depresyon, sürekli üzüntü, ilgisizlik ve enerji kaybı ile karakterize bir ruhsal bozukluktur. '
            'Yaşam kalitesini ve günlük işlevselliği etkiler.\n\n'
            'Mücadele Yöntemleri:\n'
            '- Profesyonel yardım alın (psikolog, psikiyatrist).\n'
            '- Düzenli egzersiz yapın.\n'
            '- Sağlıklı beslenmeye özen gösterin.\n'
            '- Sosyal destek alın, sevdiklerinizle iletişim kurun.\n'
            '- Günlük rutin oluşturun.\n'
            '- Gerektiğinde ilaç tedavisi uygulanabilir.\n\n'
            'Unutmayın, depresyon tedavi edilebilir bir hastalıktır.'
      : 'Depression is a mental disorder characterized by persistent sadness, lack of interest, and loss of energy. '
            'It affects quality of life and daily functioning.\n\n'
            'Coping Strategies:\n'
            '- Seek professional help (psychologist, psychiatrist).\n'
            '- Exercise regularly.\n'
            '- Eat a healthy diet.\n'
            '- Maintain social support and communication.\n'
            '- Create a daily routine.\n'
            '- Medication may be used if needed.\n\n'
            'Remember, depression is a treatable condition.';

  String get menu => language == 'tr' ? 'Menü' : 'Menu';
  String get home => language == 'tr' ? 'Ana Sayfa' : 'Home';

  String get breathingExercise =>
      language == 'tr' ? 'Nefes Egzersizi' : 'Breathing Exercise';
  String get dailyJournal => language == 'tr' ? 'Günlük Tut' : 'Daily Journal';
  String get giveMeTask =>
      language == 'tr' ? 'Bana bir görev ver' : 'Give me a task';
  String get mood => language == 'tr' ? 'Ruh Hali' : 'Mood';
  String get moodHistory =>
      language == 'tr' ? 'Ruh Hali Geçmişi' : 'Mood History';
  String get aboutDepression =>
      language == 'tr' ? 'Depresyon Hakkında' : 'About Depression';
  String get emergencySupport =>
      language == 'tr' ? 'Acil Destek' : 'Emergency Support';
  String get couldNotOpenLink =>
      language == 'tr' ? 'Bağlantı açılamadı.' : 'Could not open link.';

  String get moodSelectTitle =>
      language == 'tr' ? 'Ruh halini seç' : 'Select your mood';
  String get confirmDelete =>
      language == 'tr' ? 'Silme Onayı' : 'Confirm Deletion';
  String get confirmDeleteMsg => language == 'tr'
      ? 'Silmek istediğine emin misin?'
      : 'Are you sure you want to delete?';

  String get delete => language == 'tr' ? 'Sil' : 'Delete';
  String get noMoodHistory =>
      language == 'tr' ? 'Henüz ruh hali kaydı yok' : 'No mood history found';

  String get journalPrompt =>
      language == 'tr' ? 'Düşüncelerini yaz' : 'Write down your thoughts';
  String get journalHint => language == 'tr' ? 'Buraya yaz...' : 'Type here...';
  String get save => language == 'tr' ? 'Kaydet' : 'Save';
  String get noJournalEntries =>
      language == 'tr' ? 'Henüz bir kayıt yok' : 'No entries yet';
  String get deleteConfirmationTitle =>
      language == 'tr' ? 'Kaydı Sil' : 'Delete Entry';
  String get deleteConfirmationMsg => language == 'tr'
      ? 'Bu kaydı silmek istediğine emin misin?'
      : 'Do you want to delete this entry?';

  String get start => language == 'tr' ? 'Başla' : 'Start';
  String get stop => language == 'tr' ? 'Durdur' : 'Stop';
  String get reset => language == 'tr' ? 'Sıfırla' : 'Reset';

  List<String> get moodLabels => language == 'tr'
      ? ['Çok Üzgün', 'Üzgün', 'Nötr', 'Mutlu', 'Çok Mutlu']
      : ['Very Sad', 'Sad', 'Neutral', 'Happy', 'Very Happy'];

  List<String> get smallTasks => language == 'tr'
      ? [
          'Bir bardak su iç',
          'Kollarını ger',
          '5 dakikalığına dışarı çık',
          'Olumlu bir şey yaz',
          'Aynaya gülümse',
          'Derin bir nefes al',
          'Birine nazik bir mesaj gönder',
          'Sevdiğin bir şarkıyı dinle',
          '10 defa zıpla',
          '5 dakika boyunca etrafı topla',
        ]
      : [
          'Drink a glass of water',
          'Stretch your arms',
          'Step outside for 5 minutes',
          'Write something positive',
          'Smile at yourself in the mirror',
          'Take a deep breath',
          'Send a kind message to someone',
          'Listen to a favorite song',
          'Do 10 jumping jacks',
          'Tidy your space for 5 minutes',
        ];

  String get anxietyTitle => language == 'tr' ? 'Anksiyete' : 'Anxiety';

  String get bmiUnderweight => language == 'tr' ? 'Zayıf' : 'Underweight';
  String get bmiUnderweightInfo => language == 'tr'
      ? 'Zayıf olmanız, beslenme yetersizliği, enerji eksikliği ve bağışıklık sisteminin zayıflamasına yol açabilir. Kemik yoğunluğunuzda azalma, kas kütlesinde kayıp ve hormon dengesizlikleri gelişebilir. Bu durum, enfeksiyonlara karşı dirençsizlik ve yorgunluk gibi sağlık problemlerine neden olabilir. Bir uzmana danışmanız önerilir.'
      : 'Being underweight may lead to nutritional deficiencies, energy shortage, and weakened immune system. It can cause decreased bone density, muscle loss, and hormonal imbalances. This condition may result in susceptibility to infections and fatigue. Consulting a healthcare professional is advised.';

  String get bmiNormal => language == 'tr' ? 'Normal' : 'Normal';
  String get bmiNormalInfo => language == 'tr'
      ? 'Kilonuz ideal aralıkta ve sağlığınız için olumlu bir durumdur. Dengeli beslenme, düzenli egzersiz ve iyi uyku alışkanlıkları ile bu sağlıklı kiloyu korumaya devam etmek önemlidir. Düzenli sağlık kontrolleri ile genel sağlığınızı destekleyin.'
      : 'Your weight is within the ideal range and is positive for your health. Maintaining this healthy weight through balanced nutrition, regular exercise, and good sleep habits is important. Support your overall health with regular medical check-ups.';

  String get bmiOverweight => language == 'tr' ? 'Fazla Kilolu' : 'Overweight';
  String get bmiOverweightInfo => language == 'tr'
      ? 'Fazla kilolu olmak, kalp-damar hastalıkları, yüksek tansiyon, tip 2 diyabet ve bazı kanser türleri riskini artırabilir. Aynı zamanda eklem ağrıları ve solunum problemleri gibi rahatsızlıklar ortaya çıkabilir. Sağlıklı beslenme ve fiziksel aktivite ile kilo kontrolü sağlanması önerilir.'
      : 'Being overweight increases the risk of cardiovascular diseases, high blood pressure, type 2 diabetes, and some types of cancer. It can also cause joint pain and respiratory problems. It is recommended to manage weight through healthy diet and physical activity.';

  String get bmiObese => language == 'tr' ? 'Obez' : 'Obese';
  String get bmiObeseInfo => language == 'tr'
      ? 'Obezite, kalp hastalıkları, inme, diyabet, hipertansiyon, uyku apnesi ve bazı kanser türleri dahil olmak üzere birçok ciddi sağlık sorununa yol açabilir. Ayrıca yaşam kalitesini düşürebilir ve hareket kabiliyetini kısıtlayabilir. Kapsamlı bir sağlık değerlendirmesi ve uzman desteği ile kilo verme planı yapılması çok önemlidir.'
      : 'Obesity can lead to many serious health problems including heart disease, stroke, diabetes, hypertension, sleep apnea, and some types of cancer. It can also reduce quality of life and limit mobility. It is crucial to develop a weight loss plan with comprehensive health evaluation and expert support.';

  String get anxietyTestButton =>
      language == 'tr' ? 'Anksiyete Testi' : 'Anxiety Test';
  String get groundingExercises =>
      language == 'tr' ? 'Zemin Sağlama Egzersizleri' : 'Grounding Exercises';

  String get selectSleepTime =>
      language == 'tr' ? 'Uyku Saatini Seç' : 'Select Sleep Time';
  String get sleepTime => language == 'tr' ? 'Yatma Saati' : 'Bedtime';

  String get cancelSleepAlarm =>
      language == 'tr' ? 'Uyku Alarmını Kapat' : 'Cancel Sleep Alarm';

  String get selectWakeTime =>
      language == 'tr' ? 'Uyanma Saatini Seç' : 'Select Wake Time';
  String get wakeTime => language == 'tr' ? 'Uyanma Saati' : 'Wake-up Time';

  String get cancelWakeAlarm =>
      language == 'tr' ? 'Uyanma Alarmını Kapat' : 'Cancel Wake Alarm';

  String get showTasks => language == 'tr' ? 'Görevleri Göster' : 'Show Tasks';
  String get hideTasks => language == 'tr' ? 'Görevleri Gizle' : 'Hide Tasks';

  String get showSleepTips =>
      language == 'tr' ? 'İyi Uyku İpuçları' : 'Good Sleep Tips';
  String get hideTips => language == 'tr' ? 'İpuçlarını Gizle' : 'Hide Tips';

  String get alarmTitle => language == 'tr' ? 'Alarm!' : 'Alarm!';
  String get alarmMessage =>
      language == 'tr' ? 'Alarm zamanı geldi.' : 'It\'s time!';
  String get close => language == 'tr' ? 'Kapat' : 'Close';

  String get groundingExercise1 => language == 'tr'
      ? '5-4-3-2-1 yöntemi ile çevrenizdeki nesneleri sayın.'
      : 'Use the 5-4-3-2-1 method to count objects around you.';

  String get groundingExercise2 => language == 'tr'
      ? 'Derin nefes alıp verin, nefesinize odaklanın.'
      : 'Take deep breaths and focus on your breathing.';

  String get groundingExercise3 => language == 'tr'
      ? 'Ellerinizi yıkayın, suyun hissini hissedin.'
      : 'Wash your hands and feel the sensation of water.';

  String get groundingExercise4 => language == 'tr'
      ? 'Bir nesneyi detaylı inceleyin (renk, doku, şekil).'
      : 'Examine an object in detail (color, texture, shape).';

  String get groundingExercise5 => language == 'tr'
      ? 'Ayaklarınızı yere sağlam basarak oturun ve hissetmeye çalışın.'
      : 'Sit firmly with your feet on the ground and try to feel it.';

  List<String> get ansietyQuestions {
    return language == 'tr'
        ? [
            "1. Son 2 hafta içinde ne sıklıkla, sinirli, endişeli ya da gergin hissettiniz?",
            "2. Kontrol edemediğiniz şekilde endişelendiniz mi?",
            "3. Rahatsız edici derecede çok fazla endişelendiniz mi?",
            "4. Rahatlayamadığınız, huzursuz olduğunuz zamanlar oldu mu?",
            "5. Kolayca sinirlendiğiniz veya öfkelendiğiniz oldu mu?",
            "6. Korku ya da panik hissi yaşadınız mı?",
            "7. Anksiyeteniz günlük hayatınızı etkiledi mi?",
          ]
        : [
            "1. Over the last 2 weeks, how often have you felt nervous, anxious, or on edge?",
            "2. Were you unable to control your worrying?",
            "3. Did you worry too much about different things?",
            "4. Did you have trouble relaxing or feeling restless?",
            "5. Were you easily annoyed or irritable?",
            "6. Did you feel afraid as if something awful might happen?",
            "7. Did your anxiety interfere with your daily life?",
          ];
  }

  String get breathe => language == 'tr' ? 'Nefes Al' : 'Breathe';
  String get holdBreath => language == 'tr' ? 'Nefesi Tut' : 'Hold Breath';
  String get exhale => language == 'tr' ? 'Nefes Ver' : 'Exhale';

  String get bmiHistory => language == 'tr' ? 'BMI Geçmişi' : 'BMI History';
  String get noBmiHistory =>
      language == 'tr' ? 'Henüz bir BMI kaydı yok.' : 'No BMI records yet.';
  String get dailyMeals => language == 'tr' ? 'Günlük Öğünler' : 'Daily Meals';

  String get meal => language == 'tr' ? 'Yemek' : 'Meal';

  String get waterReminder =>
      language == 'tr' ? 'Su Hatırlatıcısı' : 'Water Reminder';
  String get glassesDrank =>
      language == 'tr' ? 'İçilen Bardak Sayısı' : 'Glasses Drank';

  String get drinkOneGlass =>
      language == 'tr' ? '1 Bardak İç' : 'Drink 1 Glass';

  String get showSavedMeals =>
      language == 'tr' ? 'Kayıtlı Yemekleri Göster' : 'Show Saved Meals';
  String get noMealsSaved =>
      language == 'tr' ? 'Henüz yemek kaydı yok.' : 'No meals saved yet.';
  String get enterMeal => language == 'tr' ? 'Yemek girin' : 'Enter meal';

  String get saved => language == 'tr' ? 'Kaydedildi!' : 'Saved!';
  String get clearHistory =>
      language == 'tr' ? 'Geçmişi Temizle' : 'Clear History';

  String get bmiCalculator =>
      language == 'tr' ? 'BMI Hesaplayıcı' : 'BMI Calculator';
  String get enterHeight => language == 'tr' ? 'Boy (cm)' : 'Height (cm)';
  String get enterWeight => language == 'tr' ? 'Kilo (kg)' : 'Weight (kg)';
  String get calculate => language == 'tr' ? 'Hesapla' : 'Calculate';
  String get bmiResult => language == 'tr' ? 'BMI Sonucu' : 'BMI Result';
  String get invalidInput =>
      language == 'tr' ? 'Geçersiz giriş!' : 'Invalid input!';

  String get task1 => language == 'tr'
      ? 'Yatmadan 30 dakika önce ekran kullanımını bıraktım'
      : 'I stopped using screens 30 minutes before bed';

  String get task2 => language == 'tr'
      ? 'Yatmadan önce telefonumu uçak moduna aldım'
      : 'I put my phone on airplane mode before bed';

  String get task3 => language == 'tr'
      ? 'Yatmadan önce 5 dakika derin nefes egzersizi yaptım'
      : 'I did 5 minutes of deep breathing exercises before bed';

  String get task4 => language == 'tr'
      ? 'Akşam kafeinli içecek tüketmedim (çay, kahve, enerji içeceği)'
      : 'I avoided caffeinated drinks in the evening (tea, coffee, energy drinks)';

  String get task5 => language == 'tr'
      ? 'Yatak odamı karanlık ve sessiz hale getirdim'
      : 'I made my bedroom dark and quiet';

  String get task6 => language == 'tr'
      ? 'Yatmadan önce hafif esneme hareketleri yaptım'
      : 'I did light stretching before bed';

  String get smokingAddiction =>
      language == 'tr' ? 'Sigara Bağımlılığı' : 'Smoking Addiction';
  String get smokingQuestion => language == 'tr'
      ? 'Sigara bağımlılığından kurtulmak için hangi yöntemi denemek istersin?'
      : 'Which method would you like to try to quit smoking?';
  String get coldTurkey => language == 'tr'
      ? 'Aniden Bırakmak İstiyorum'
      : 'I Want to Quit Cold Turkey';
  String get gradualReduction => language == 'tr'
      ? 'Aşamalı Olarak Azaltmak İstiyorum'
      : 'I Want to Reduce Gradually';

  String get task7 => language == 'tr'
      ? 'Ağır ve geç yemeklerden kaçındım'
      : 'I avoided heavy and late meals';

  String get task8 => language == 'tr'
      ? 'Oda sıcaklığını uyumak için uygun hale getirdim'
      : 'I adjusted the room temperature to a comfortable level for sleep';

  String get task9 => language == 'tr'
      ? 'Yatmadan önce kitap okudum veya dua ettim'
      : 'I read a book or meditated before bed';

  String get task10 => language == 'tr'
      ? 'Her gün aynı saatte yatmaya çalıştım'
      : 'I tried to go to bed at the same time every day';

  String get sleepTip1 => language == 'tr' ? '' : '';
  String get sleepTip2 => language == 'tr' ? '' : '';
  String get sleepTip3 => language == 'tr' ? '' : '';

  String get sleptAt => language == 'tr' ? 'Yattığın saat' : 'Slept at';
  String get wokeUpAt => language == 'tr' ? 'Uyandığın saat' : 'Woke up at';

  // Her cevap için 2 dilde seçenekler (Türkçe-İngilizce)
  List<String> get answerOption0 => ["Hiç", "Not at all"];
  List<String> get answerOption1 => ["Birkaç gün", "Several days"];
  List<String> get answerOption2 => [
    "Yarıdan fazla gün",
    "More than half the days",
  ];
  List<String> get answerOption3 => ["Neredeyse her gün", "Nearly every day"];

  // Anksiyete durumları
  String get minimalAnxiety =>
      language == 'tr' ? "Minimal anksiyete" : "Minimal anxiety";
  String get mildAnxiety =>
      language == 'tr' ? "Hafif anksiyete" : "Mild anxiety";
  String get moderateAnxiety =>
      language == 'tr' ? "Orta düzey anksiyete" : "Moderate anxiety";
  String get severeAnxiety =>
      language == 'tr' ? "Ağır anksiyete" : "Severe anxiety";

  // Başlıklar ve metinler
  String get medicalInfoTitle => language == 'tr'
      ? "Tıbbi Bilgi ve Öneriler:"
      : "Medical Information and Recommendations:";
  String get anxietyDescription => language == 'tr'
      ? "Anksiyete seviyenizi değerlendirmek için aşağıdaki soruları yanıtlayınız."
      : "Answer the following questions to assess your anxiety level.";

  // Test sonucu dialog metinleri
  String get testResultTitle =>
      language == 'tr' ? "Test Sonucu" : "Test Result";
  String get totalScore =>
      language == 'tr' ? "Toplam puanınız" : "Your total score";
  String get status => language == 'tr' ? "Durum" : "Status";
  String get ok => language == 'tr' ? "Tamam" : "OK";
  String get showResult => language == 'tr' ? "Sonucu Göster" : "Show Result";

  // Tıbbi öneriler listeleri
  List<String> get minimalAnxietyTips {
    return language == 'tr'
        ? [
            "Anksiyete belirtileriniz minimal düzeydedir. Günlük stres yönetimi ve düzenli yaşam tarzı sürdürmeniz faydalıdır.",
            "Düzenli egzersiz, yeterli uyku ve dengeli beslenme, ruh sağlığınızı destekler.",
            "Meditasyon, nefes egzersizleri ve gevşeme tekniklerini günlük rutininize ekleyebilirsiniz.",
          ]
        : [
            "Your anxiety symptoms are minimal. Maintaining daily stress management and a regular lifestyle is beneficial.",
            "Regular exercise, sufficient sleep, and balanced nutrition support your mental health.",
            "You can add meditation, breathing exercises, and relaxation techniques to your daily routine.",
          ];
  }

  List<String> get mildAnxietyTips {
    return language == 'tr'
        ? [
            "Hafif anksiyete belirtileri yaşıyorsunuz. Bu seviyede, bilişsel davranışçı terapi tekniklerini araştırabilir ve uygulayabilirsiniz.",
            "Stres azaltıcı aktiviteler ve nefes egzersizleri anksiyetenizi kontrol altında tutmaya yardımcı olur.",
            "Günlük kaygılarınızda profesyonel destek almak faydalı olabilir.",
            "Eğer belirtiler artarsa bir psikiyatrist veya psikoloğa danışmanız önerilir.",
          ]
        : [
            "You are experiencing mild anxiety symptoms. You can research and apply cognitive behavioral therapy techniques at this level.",
            "Stress-reducing activities and breathing exercises help keep your anxiety under control.",
            "Professional support may be helpful for your daily worries.",
            "If symptoms worsen, consulting a psychiatrist or psychologist is recommended.",
          ];
  }

  List<String> get moderateAnxietyTips {
    return language == 'tr'
        ? [
            "Orta düzey anksiyete, günlük yaşamınızı etkileyebilir ve profesyonel destek gerektirebilir.",
            "Psikoterapi (özellikle bilişsel davranışçı terapi) önerilir.",
            "Düzenli egzersiz, meditasyon ve nefes teknikleri belirtileri hafifletmeye yardımcı olur.",
            "İlaç tedavisi için bir uzmana başvurmanız gerekebilir.",
            "Kendinizi aşırı zorlamayın ve destek sistemlerinden faydalanın.",
          ]
        : [
            "Moderate anxiety may affect your daily life and may require professional support.",
            "Psychotherapy (especially cognitive behavioral therapy) is recommended.",
            "Regular exercise, meditation, and breathing techniques help alleviate symptoms.",
            "You may need to consult a specialist for medication treatment.",
            "Do not overexert yourself and benefit from support systems.",
          ];
  }

  List<String> get severeAnxietyTips {
    return language == 'tr'
        ? [
            "Ağır anksiyete durumları, profesyonel tıbbi müdahale gerektirir.",
            "Bir psikiyatrist veya klinik psikolog ile acilen görüşmeniz önerilir.",
            "Bilişsel davranışçı terapi, ilaç tedavisi ve diğer tedavi yöntemleri anksiyetenin kontrol altına alınmasında etkilidir.",
            "Kriz anlarında acil yardım hatları aranabilir.",
            "Bu süreçte kendinizi yalnız hissetmeyin, destek alın.",
          ]
        : [
            "Severe anxiety conditions require professional medical intervention.",
            "It is recommended to urgently see a psychiatrist or clinical psychologist.",
            "Cognitive behavioral therapy, medication, and other treatment methods are effective in controlling anxiety.",
            "Emergency help lines can be called in crisis situations.",
            "Do not feel alone during this process; get support.",
          ];
  }

  String get title => 'Medivio';
  String get welcome =>
      language == 'tr' ? 'Medivio\'ya Hoşgeldiniz!' : 'Welcome to Medivio!';

  String get settings => language == 'tr' ? 'Ayarlar' : 'Settings';
  String get selectedLanguage =>
      language == 'tr' ? 'Seçilen dil:' : 'Selected language:';

  String get languageOption =>
      language == 'tr' ? 'Dil Seçeneği' : 'Language Option';

  String get stress =>
      language == 'tr' ? 'Stres ve Anksiyete' : 'Stress & Anxiety';
  String get stressDesc => language == 'tr'
      ? 'Stres ve anksiyeteyle başa çıkmak için nefes egzersizleri, meditasyon ve spor önerilir.'
      : 'To manage stress and anxiety, breathing exercises, meditation, and physical activity are recommended.';

  String get sleep => language == 'tr' ? 'Uyku Problemleri' : 'Sleep Problems';
  String get sleepDesc => language == 'tr'
      ? 'Düzenli uyku saatleri belirleyin, yatmadan önce ekran süresini azaltın.'
      : 'Set regular sleep hours and reduce screen time before bedtime.';

  String get nutrition =>
      language == 'tr' ? 'Beslenme Alışkanlıkları' : 'Nutrition Habits';
  String get nutritionDesc => language == 'tr'
      ? 'Dengeli beslenmeye özen gösterin, bol su tüketin ve işlenmiş gıdalardan kaçının.'
      : 'Focus on balanced nutrition, drink plenty of water, and avoid processed foods.';

  String get depression => language == 'tr' ? 'Depresyon' : 'Depression';

  String get addictions => language == 'tr' ? 'Bağımlılıklar' : 'Addictions';
  String get addictionsDesc => language == 'tr'
      ? 'Dijital detoks yapın, bağımlılıklarınızın farkında olun ve destek alın.'
      : 'Do digital detox, be aware of your addictions, and seek support.';

  // DepressionPage çevirileri
  String get selectOption =>
      language == 'tr' ? 'Bir seçenek seçin:' : 'Choose an option:';

  String get selectOptionHint =>
      language == 'tr' ? 'Bir seçenek seçin.' : 'Select an option.';

  // Dialog çevirileri

  // MoodHistory çevirileri

  // localization.dart içinde
  String get dersCalisma =>
      language == 'tr' ? 'Ders çalışmak istemiyorum' : 'I don\'t want to study';
  String get sikUyku =>
      language == 'tr' ? 'Sürekli uykum var' : 'I feel sleepy all the time';
  String get odaklanamama =>
      language == 'tr' ? 'Odaklanamıyorum' : 'I can\'t concentrate';
  String get diger => language == 'tr' ? 'Diğer' : 'Other';

  String get selectSymptom =>
      language == 'tr' ? 'Belirtilerden birini seçin:' : 'Select a symptom:';
}
